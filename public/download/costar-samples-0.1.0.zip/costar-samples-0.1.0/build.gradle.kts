// Costar API 多模块构建根脚本。
// 各模块按平台归属选择插件:平台无关模块使用 kotlin("jvm"),Android 相关模块使用 Android 插件。
plugins {
    alias(libs.plugins.kotlin.jvm) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.android.library) apply false
    alias(libs.plugins.android.application) apply false
}
