package com.costar.samples.page

import android.content.Context
import android.content.Intent
import com.costar.samples.core.Domain

internal class SubGroupPage : VerificationPage() {

    override val domain: Domain by lazy {
        Domain.valueOf(intent.getStringExtra(EXTRA_DOMAIN) ?: Domain.DEVICE.name)
    }

    override val groupTitle: String? by lazy { intent.getStringExtra(EXTRA_GROUP) }

    companion object {

        private const val EXTRA_DOMAIN = "domain"

        private const val EXTRA_GROUP = "group"

        fun intent(context: Context, domain: Domain, groupTitle: String): Intent =
            Intent(context, SubGroupPage::class.java).apply {
                putExtra(EXTRA_DOMAIN, domain.name)
                putExtra(EXTRA_GROUP, groupTitle)
            }
    }
}