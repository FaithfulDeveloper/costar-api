package com.costar.samples.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.VideoView
import java.io.File

internal object Palette {

    val BG = Color.parseColor("#F4F6F8")
    val CARD = Color.parseColor("#FFFFFF")
    val STROKE = Color.parseColor("#E4E9ED")

    val TEXT = Color.parseColor("#1B1F23")
    val MUTED = Color.parseColor("#6B737C")

    val BRAND = Color.parseColor("#0FA69C")
    val BRAND_BG = Color.parseColor("#E6F6F4")

    val OK = Color.parseColor("#12A76A")
    val OK_BG = Color.parseColor("#E6F7EF")

    val WARN = Color.parseColor("#B5771B")
    val WARN_BG = Color.parseColor("#FCF4E5")

    val DANGER = Color.parseColor("#D64545")
    val DANGER_BG = Color.parseColor("#FDF0F0")

    val NEUTRAL = Color.parseColor("#6B737C")
    val NEUTRAL_BG = Color.parseColor("#F1F3F5")
}

internal enum class Tone(private val fgColor: Int, private val bgColor: Int) {
    BRAND(Palette.BRAND, Palette.BRAND_BG),
    OK(Palette.OK, Palette.OK_BG),
    WARN(Palette.WARN, Palette.WARN_BG),
    DANGER(Palette.DANGER, Palette.DANGER_BG),
    MUTED(Palette.NEUTRAL, Palette.NEUTRAL_BG);

    val fg: Int get() = fgColor
    val bg: Int get() = bgColor
}

internal fun Context.dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

internal fun Context.rounded(
    fill: Int,
    cornerDp: Int,
    stroke: Int? = null,
    strokeDp: Int = 1
): GradientDrawable = GradientDrawable().apply {
    shape = GradientDrawable.RECTANGLE
    setColor(fill)
    cornerRadius = dp(cornerDp).toFloat()
    if (stroke != null) setStroke(dp(strokeDp), stroke)
}

internal fun Context.screen(build: LinearLayout.() -> Unit): ScrollView {
    val content = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(32))
        setBackgroundColor(Palette.BG)
    }
    content.build()
    return ScrollView(this).apply {
        isFillViewport = true
        setBackgroundColor(Palette.BG)
        addView(content)
    }
}

internal fun Context.pageHeader(
    title: String,
    subtitle: String?,
    onBack: (() -> Unit)?,
    action: View? = null
): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(4), dp(4), dp(4), dp(12))

    if (onBack != null) {
        addView(
            TextView(this@pageHeader).apply {
                text = "‹ 返回"
                textSize = 14f
                setTextColor(Palette.BRAND)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(0, 0, 0, dp(8))
                setOnClickListener { onBack() }
            }
        )
    }

    val titleRow = LinearLayout(this@pageHeader).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }
    titleRow.addView(
        TextView(this@pageHeader).apply {
            text = title
            textSize = 22f
            setTextColor(Palette.TEXT)
            typeface = Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
    )
    if (action != null) {
        titleRow.addView(action)
    }
    addView(titleRow)

    if (!subtitle.isNullOrBlank()) {
        addView(
            TextView(this@pageHeader).apply {
                text = subtitle
                textSize = 13f
                setTextColor(Palette.MUTED)
                setPadding(0, dp(6), 0, 0)
            }
        )
    }
}

internal fun Context.chip(text: String, tone: Tone): TextView = TextView(this).apply {
    this.text = text
    textSize = 12f
    setTextColor(tone.fg)
    typeface = Typeface.DEFAULT_BOLD
    setPadding(dp(8), dp(3), dp(8), dp(3))
    background = rounded(tone.bg, 6)
}

internal fun Context.navRow(
    title: String,
    subtitle: String,
    subtitleTone: Tone,
    enabled: Boolean,
    onClick: () -> Unit
): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    gravity = Gravity.CENTER_VERTICAL
    setPadding(dp(14), dp(14), dp(14), dp(14))
    background = rounded(Palette.CARD, 12, Palette.STROKE)
    alpha = if (enabled) 1f else 0.55f
    setOnClickListener { onClick() }

    addView(
        LinearLayout(this@navRow).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            addView(
                TextView(this@navRow).apply {
                    text = title
                    textSize = 15f
                    setTextColor(if (enabled) Palette.TEXT else Palette.MUTED)
                    typeface = Typeface.DEFAULT_BOLD
                }
            )
            addView(
                TextView(this@navRow).apply {
                    text = subtitle
                    textSize = 12f
                    setTextColor(if (enabled) subtitleTone.fg else Palette.MUTED)
                    setPadding(0, dp(4), 0, 0)
                }
            )
        }
    )
    addView(
        TextView(this@navRow).apply {
            text = ">"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Palette.MUTED)
        }
    )
}

internal fun Context.card(
    title: String,
    body: View,
    subtitle: String? = null,
    headerAction: View? = null,
    contentPaddingTop: Int = 12
): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(14), dp(14), dp(14), dp(14))
    background = rounded(Palette.CARD, 12, Palette.STROKE)

    val header = LinearLayout(this@card).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }
    header.addView(
        LinearLayout(this@card).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            addView(
                TextView(this@card).apply {
                    text = title
                    textSize = 15f
                    setTextColor(Palette.TEXT)
                    typeface = Typeface.DEFAULT_BOLD
                }
            )
            if (!subtitle.isNullOrBlank()) {
                addView(
                    TextView(this@card).apply {
                        text = subtitle
                        textSize = 12f
                        setTextColor(Palette.MUTED)
                        setPadding(0, dp(4), 0, 0)
                    }
                )
            }
        }
    )
    if (headerAction != null) {
        header.addView(headerAction)
    }
    addView(header)

    addView(
        body,
        LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(contentPaddingTop) }
    )
}

internal fun Context.primaryButton(text: String, onClick: () -> Unit): Button =
    actionButton(text, Tone.BRAND, filled = true, onClick = onClick)

internal fun Context.secondaryButton(text: String, onClick: () -> Unit): Button =
    actionButton(text, Tone.BRAND, filled = false, onClick = onClick)

internal fun Context.dangerButton(text: String, onClick: () -> Unit): Button =
    actionButton(text, Tone.DANGER, filled = false, onClick = onClick)

private fun Context.actionButton(
    text: String,
    tone: Tone,
    filled: Boolean,
    onClick: () -> Unit
): Button = Button(this).apply {
    this.text = text
    textSize = 14f
    isAllCaps = false
    setTextColor(if (filled) Color.WHITE else tone.fg)
    background = rounded(if (filled) tone.fg else Palette.CARD, 10, tone.fg)
    setOnClickListener { onClick() }
}

internal fun Context.kvRow(key: String, value: String): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    setPadding(0, dp(3), 0, dp(3))
    addView(
        TextView(this@kvRow).apply {
            text = key
            textSize = 13f
            setTextColor(Palette.MUTED)
            layoutParams = LinearLayout.LayoutParams(dp(96), LinearLayout.LayoutParams.WRAP_CONTENT)
        }
    )
    addView(
        TextView(this@kvRow).apply {
            text = value
            textSize = 13f
            setTextColor(Palette.TEXT)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
    )
}

internal fun Context.monoBlock(text: String, textSizeSp: Float = 12f): TextView = TextView(this).apply {
    this.text = text
    this.textSize = textSizeSp
    setTextColor(Palette.TEXT)
    typeface = Typeface.MONOSPACE
    setTextIsSelectable(true)
}

internal fun Context.hint(text: String): TextView = TextView(this).apply {
    this.text = text
    textSize = 12f
    setTextColor(Palette.MUTED)
}

internal fun Context.divider(): View = View(this).apply {
    setBackgroundColor(Palette.STROKE)
    layoutParams = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        dp(1)
    ).apply { topMargin = dp(8); bottomMargin = dp(8) }
}

internal fun decodeSampledImage(file: File, maxWidth: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / sample > maxWidth || bounds.outHeight / sample > maxWidth) {
        sample *= 2
    }
    return runCatching {
        BitmapFactory.decodeFile(
            file.absolutePath,
            BitmapFactory.Options().apply { inSampleSize = sample }
        )
    }.getOrNull()
}

internal fun Context.imagePreview(file: File, maxWidth: Int = 720): View? {
    val bitmap = decodeSampledImage(file, maxWidth) ?: return null
    return ImageView(this).apply {
        setImageBitmap(bitmap)
        adjustViewBounds = true
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(6) }
    }
}

internal class AudioPlaybackRow(private val context: Context, private val file: File) {

    private var player: MediaPlayer? = null

    private val status: TextView = TextView(context).apply {
        text = "${file.name}   ${file.length() / 1024} KB"
        textSize = 12f
        setTextColor(Palette.MUTED)
    }

    private val toggle: Button = Button(context).apply {
        text = "播放"
        textSize = 13f
        isAllCaps = false
        minWidth = context.dp(64)
        minHeight = context.dp(36)
        setTextColor(Tone.BRAND.fg)
        background = context.rounded(Palette.CARD, 8, Tone.BRAND.fg)
        setOnClickListener { togglePlayback() }
    }

    val view: LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, context.dp(6), 0, 0)
        addView(toggle)
        addView(
            status,
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                .apply { leftMargin = context.dp(10) }
        )
    }

    private fun togglePlayback() {
        if (player?.let { runCatching { it.isPlaying }.getOrDefault(false) } == true) {
            release()
            return
        }
        release()
        val instance = MediaPlayer()
        val prepared = runCatching {
            instance.setDataSource(file.absolutePath)
            instance.setOnCompletionListener { release() }
            instance.setOnErrorListener { _, _, _ ->
                release()
                status.text = "播放失败: ${file.name}"
                true
            }
            instance.prepare()
        }
        if (prepared.isFailure) {
            runCatching { instance.release() }
            status.text = "无法播放: ${prepared.exceptionOrNull()?.message}"
            return
        }
        player = instance
        runCatching { instance.start() }
        toggle.text = "停止"
    }

    fun release() {
        player?.let { current ->
            runCatching { current.stop() }
            runCatching { current.release() }
        }
        player = null
        toggle.text = "播放"
    }
}

internal class VideoPlaybackView(private val context: Context, private val file: File) {

    private var prepared = false

    private var playRequested = false

    private val player: VideoView = VideoView(context).apply {
        setVideoPath(file.absolutePath)
        setOnPreparedListener { media ->
            prepared = true
            if (playRequested) media.start()
        }
        setOnCompletionListener {
            playRequested = false
            toggle.text = "播放"
        }
        setOnErrorListener { _, what, extra ->
            prepared = false
            playRequested = false
            toggle.text = "播放"
            status.text = "播放失败: ${file.name} (what=$what, extra=$extra)"
            true
        }
    }

    private val status: TextView = TextView(context).apply {
        text = "${file.name}   ${file.length() / 1024} KB"
        textSize = 12f
        setTextColor(Palette.MUTED)
    }

    private val toggle: Button = Button(context).apply {
        text = "播放"
        textSize = 13f
        isAllCaps = false
        minWidth = context.dp(64)
        minHeight = context.dp(36)
        setTextColor(Tone.BRAND.fg)
        background = context.rounded(Palette.CARD, 8, Tone.BRAND.fg)
        setOnClickListener { togglePlayback() }
    }

    val view: LinearLayout = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(0, context.dp(6), 0, 0)
        addView(
            LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                addView(toggle)
                addView(
                    status,
                    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                        .apply { leftMargin = context.dp(10) }
                )
            }
        )
        addView(
            player,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                context.dp(VIDEO_HEIGHT_DP)
            ).apply { topMargin = context.dp(6) }
        )
    }

    private fun togglePlayback() {
        if (player.isPlaying) {
            player.pause()
            playRequested = false
            toggle.text = "继续"
            return
        }
        playRequested = true
        if (prepared) player.start()
        toggle.text = "暂停"
    }

    fun release() {
        playRequested = false
        runCatching { player.stopPlayback() }
        toggle.text = "播放"
    }

    private companion object {
        const val VIDEO_HEIGHT_DP = 180
    }
}
