package com.costar.samples.core

import java.io.File

internal enum class VerifyStatus {
    PENDING,

    RUNNING,

    PASS,

    FAIL,

    UNSUPPORTED
}

internal data class VerifyState(val status: VerifyStatus, val detail: String)

internal sealed interface VerificationMedia {

    val file: File

    val label: String

    class Image(override val file: File, override val label: String) : VerificationMedia

    class Audio(override val file: File, override val label: String) : VerificationMedia

    class Video(override val file: File, override val label: String) : VerificationMedia
}

internal object Verification {

    private val states = mutableMapOf<String, VerifyState>()

    private val media = mutableMapOf<String, VerificationMedia>()

    private val listeners = mutableListOf<(String, VerifyState) -> Unit>()

    private const val SEPARATOR = '#'

    fun key(domain: String, itemId: String): String = "$domain$SEPARATOR$itemId"

    fun record(domain: String, itemId: String, status: VerifyStatus, detail: String) {
        val state = VerifyState(status, detail)
        val targets: List<(String, VerifyState) -> Unit>
        synchronized(this) {
            states[key(domain, itemId)] = state
            targets = listeners.toList()
        }
        targets.forEach { it(key(domain, itemId), state) }
    }

    fun publishMedia(domain: String, itemId: String, value: VerificationMedia) {
        val state: VerifyState
        val targets: List<(String, VerifyState) -> Unit>
        synchronized(this) {
            media[key(domain, itemId)] = value
            state = states[key(domain, itemId)] ?: VerifyState(VerifyStatus.PENDING, "")
            targets = listeners.toList()
        }
        targets.forEach { it(key(domain, itemId), state) }
    }

    fun stateOf(domain: String, itemId: String): VerifyState? =
        synchronized(this) { states[key(domain, itemId)] }

    fun mediaOf(domain: String, itemId: String): VerificationMedia? =
        synchronized(this) { media[key(domain, itemId)] }

    fun progress(domain: Domain): Pair<Int, Int> = progress(domain, VerifyCatalog.itemsOf(domain))

    fun progress(domain: Domain, items: List<VerifyItem>): Pair<Int, Int> {
        val expected = items.count { it.isExpected() }
        val passed = items.count {
            it.isExpected() && stateOf(domain.name, it.id)?.status == VerifyStatus.PASS
        }
        return passed to expected
    }

    fun resetDomain(domain: Domain) {
        val keys = VerifyCatalog.itemsOf(domain).map { key(domain.name, it.id) }
        val targets: List<(String, VerifyState) -> Unit>
        synchronized(this) {
            keys.forEach { states.remove(it) }
            keys.forEach { media.remove(it) }
            targets = listeners.toList()
        }
        targets.forEach { it("", VerifyState(VerifyStatus.PENDING, "")) }
    }

    fun reset() {
        val targets: List<(String, VerifyState) -> Unit>
        synchronized(this) {
            states.clear()
            media.clear()
            targets = listeners.toList()
        }
        targets.forEach { it("", VerifyState(VerifyStatus.PENDING, "")) }
    }

    fun observe(listener: (String, VerifyState) -> Unit) {
        synchronized(this) { listeners.add(listener) }
    }

    fun unobserve(listener: (String, VerifyState) -> Unit) {
        synchronized(this) { listeners.remove(listener) }
    }
}
