package com.costar.samples

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.costar.api.CostarAPI
import com.costar.api.device.DeviceDescriptor
import com.costar.api.feature.FeatureLevel
import com.costar.samples.core.DemoLog
import com.costar.samples.core.DemoSession
import com.costar.samples.core.Domain
import com.costar.samples.core.Verification
import com.costar.samples.page.DeviceManagePage
import com.costar.samples.page.DevicePage
import com.costar.samples.page.LogPage
import com.costar.samples.page.TransferPage
import com.costar.samples.page.VisionPage
import com.costar.samples.page.VoicePage
import com.costar.samples.ui.Palette
import com.costar.samples.ui.Tone
import com.costar.samples.ui.card
import com.costar.samples.ui.chip
import com.costar.samples.ui.dp
import com.costar.samples.ui.navRow
import com.costar.samples.ui.pageHeader
import com.costar.samples.ui.primaryButton
import com.costar.samples.ui.screen
import com.costar.samples.ui.secondaryButton

class HomeActivity : Activity() {

    private lateinit var contentHost: LinearLayout

    private val mainHandler = Handler(Looper.getMainLooper())

    private var linkWatchdog: Runnable? = null

    private var renderedSignature: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DemoSession.attach(this)
        setContentView(buildScreen())
        DemoLog.append("应用启动,统一入口状态: ${DemoSession.runtimeState().name}")
        render(force = true)
    }

    override fun onStart() {
        super.onStart()
        startLinkWatch()
        render(force = true)
    }

    override fun onStop() {
        stopLinkWatch()
        super.onStop()
    }

    override fun onDestroy() {
        stopLinkWatch()
        mainHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

private fun buildScreen() = screen {
        addView(
            pageHeader(
                title = "Costar",
                subtitle = null,
                onBack = null,
                action = secondaryButton("日志") {
                    startActivity(Intent(this@HomeActivity, LogPage::class.java))
                }
            )
        )
        contentHost = LinearLayout(this@HomeActivity).apply {
            orientation = LinearLayout.VERTICAL
        }
        addView(contentHost)
    }

    private fun render(force: Boolean) {
        val alive = DemoSession.linkAlive()
        val descriptor = DemoSession.currentDevice()
        val vendor = DemoSession.currentVendorName()
        val signature = listOf(alive, descriptor?.model, descriptor?.vendorId?.name, vendor).toString()
        if (!force && signature == renderedSignature) return
        renderedSignature = signature

        contentHost.removeAllViews()
        contentHost.addView(connectionCard(alive, descriptor, vendor))
        contentHost.addView(sectionLabel("功能"))
        Domain.entries.forEach { domain ->
            contentHost.addView(
                featureRow(domain, alive),
                LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) }
            )
        }
    }

    private fun connectionCard(
        alive: Boolean,
        descriptor: DeviceDescriptor?,
        vendor: String?
    ): LinearLayout = if (!alive) {
        card(
            title = "未连接眼镜",
            body = primaryButton("连接眼镜") { openDevice() }
        )
    } else {
        card(
            title = "当前连接",
            body = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                addView(
                    LinearLayout(this@HomeActivity).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        addView(chip("已连接", Tone.OK))
                        addView(
                            TextView(this@HomeActivity).apply {
                                text = deviceLabel(descriptor, vendor)
                                textSize = 14f
                                setTextColor(Palette.TEXT)
                                typeface = Typeface.DEFAULT_BOLD
                                setPadding(dp(10), 0, 0, 0)
                            }
                        )
                    }
                )
                addView(
                    secondaryButton("管理") { openDevice() },
                    LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(12) }
                )
            }
        )
    }

    private fun featureRow(domain: Domain, alive: Boolean): LinearLayout {
        val supported = domain.features.any { CostarAPI.features().level(it) != FeatureLevel.NONE }
        val enabled = alive && supported
        val (passed, expected) = Verification.progress(domain)

        val subtitle = when {
            !alive -> "需要先连接眼镜"
            !supported -> "本机不支持"
            else -> "已验证 $passed/$expected"
        }
        val tone = when {
            !alive || !supported -> Tone.MUTED
            expected > 0 && passed == expected -> Tone.OK
            else -> Tone.MUTED
        }

        return navRow(domain.title, subtitle, tone, enabled) {
            when {
                !alive -> toast("请先连接眼镜")
                !supported -> toast("本机未支持该功能")
                else -> startActivity(Intent(this, pageOf(domain)))
            }
        }
    }

    private fun sectionLabel(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 14f
        setTextColor(Palette.TEXT)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(4), dp(18), 0, dp(2))
    }

    private fun deviceLabel(descriptor: DeviceDescriptor?, vendor: String?): String {
        if (descriptor == null) return "未连接"
        val vendorText = vendor?.let { " · $it" }.orEmpty()
        return "${descriptor.model}$vendorText"
    }

private fun startLinkWatch() {
        stopLinkWatch()
        val watchdog = object : Runnable {
            override fun run() {
                render(force = false)
                mainHandler.postDelayed(this, LINK_POLL_INTERVAL_MS)
            }
        }
        linkWatchdog = watchdog
        mainHandler.postDelayed(watchdog, LINK_POLL_INTERVAL_MS)
    }

    private fun stopLinkWatch() {
        linkWatchdog?.let { mainHandler.removeCallbacks(it) }
        linkWatchdog = null
    }

private fun openDevice() {
        startActivity(Intent(this, DevicePage::class.java))
    }

    private fun pageOf(domain: Domain): Class<out Activity> = when (domain) {
        Domain.DEVICE -> DeviceManagePage::class.java
        Domain.VOICE -> VoicePage::class.java
        Domain.VISION -> VisionPage::class.java
        Domain.TRANSFER -> TransferPage::class.java
    }

    private fun toast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }

    private companion object {
        const val LINK_POLL_INTERVAL_MS = 2_000L

        const val WRAP_CONTENT = LinearLayout.LayoutParams.WRAP_CONTENT

        const val MATCH_PARENT = LinearLayout.LayoutParams.MATCH_PARENT
    }
}
