package com.costar.samples.core

import android.content.Context
import com.costar.api.CostarAPI
import com.costar.api.CostarApiState
import com.costar.api.core.CostarConfig
import com.costar.api.core.CostarError
import com.costar.api.core.CostarErrorCode
import com.costar.api.core.CostarLogLevel
import com.costar.api.core.CostarResult
import com.costar.api.device.ConnectionType
import com.costar.api.device.DeviceDescriptor
import com.costar.api.platform.android.AndroidCostarPlatform
import java.io.File

internal object DemoSession {

    private const val APP_ID = "costar-samples"

    private const val SYNC_DIR_NAME = "glasses_sync"

    private const val MEDIA_DIR_NAME = "$SYNC_DIR_NAME/media"

    @Volatile
    private var appContext: Context? = null

    @Volatile
    private var currentVendor: VendorCatalog.Entry? = null

    fun attach(context: Context) {
        appContext = context.applicationContext ?: context
    }

    fun vendorEntries(): List<VendorCatalog.Entry> =
        appContext?.let { VendorCatalog.entries(it) } ?: emptyList()

    fun resolveVendor(deviceName: String): VendorCatalog.Entry? =
        appContext?.let { VendorCatalog.resolve(it, deviceName) }

    fun currentVendorName(): String? = currentVendor?.displayName

    fun runtimeReady(): Boolean = CostarAPI.state() == CostarApiState.READY

    fun linkAlive(): Boolean = CostarAPI.isLinkAlive()

    fun currentDevice(): DeviceDescriptor? = CostarAPI.deviceManager().currentDevice()

    fun runtimeState(): CostarApiState = CostarAPI.state()

    fun syncDir(): String {
        val context = appContext ?: return ""
        val dir = File(context.getExternalFilesDir(null), SYNC_DIR_NAME)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir.absolutePath
    }

    fun mediaDir(): String {
        val context = appContext ?: return ""
        val dir = File(context.getExternalFilesDir(null), MEDIA_DIR_NAME)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir.absolutePath
    }

    fun connect(
        deviceName: String,
        address: String,
        entry: VendorCatalog.Entry
    ): CostarResult<Unit> {
        val context = appContext
            ?: return failure(CostarErrorCode.INTERNAL_ERROR, "应用尚未取得上下文")

        if (CostarAPI.state() != CostarApiState.READY) {
            DemoLog.append("装配统一入口,来源 ${entry.displayName}")
            val creator = runCatching { entry.creator(context, address) }
                .onFailure { DemoLog.append("构造适配创建器异常: ${it.message}") }
                .getOrNull()
                ?: return failure(CostarErrorCode.INTERNAL_ERROR, "适配模块不可用: ${entry.displayName}")
            CostarAPI.registerAdapter(creator)
            CostarAPI.init(
                CostarConfig(
                    appId = APP_ID,
                    logLevel = CostarLogLevel.DEBUG,
                    defaultTimeoutMs = DEFAULT_TIMEOUT_MS
                ),
                AndroidCostarPlatform()
            )
            DemoLog.append("统一入口状态: ${CostarAPI.state()}")
            if (CostarAPI.state() != CostarApiState.READY) {
                return failure(CostarErrorCode.INTERNAL_ERROR, "统一入口未进入可用状态")
            }
        }

        currentVendor = entry

        return try {
            CostarAPI.deviceManager().registerDevice(
                address,
                DeviceDescriptor(
                    vendorId = entry.vendorId,
                    model = entry.modelOverride ?: deviceName,
                    firmwareVersion = "",
                    connectionType = ConnectionType.BLUETOOTH
                )
            )
            CostarAPI.deviceManager().connect(address)
        } catch (t: Throwable) {
            DemoLog.append("发起连接异常: ${t.message}")
            failure(CostarErrorCode.INTERNAL_ERROR, "发起连接异常: ${t.message}")
        }
    }

    fun release(reason: String) {
        DemoLog.append("释放眼镜链路: $reason")
        runCatching { CostarAPI.deviceManager().disconnect() }
            .onFailure { DemoLog.append("断开设备异常: ${it.message}") }
        runCatching { CostarAPI.release() }
            .onFailure { DemoLog.append("释放统一入口异常: ${it.message}") }
        currentVendor = null
        DemoLog.append("释放后统一入口状态: ${CostarAPI.state()}")
    }

    private fun failure(code: CostarErrorCode, message: String): CostarResult<Unit> =
        CostarResult.Failure(CostarError(code, message))

    private const val DEFAULT_TIMEOUT_MS = 15_000L
}
