package com.costar.samples.page

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import com.costar.samples.core.DemoSession
import com.costar.samples.core.Domain
import com.costar.samples.core.VerifyCatalog
import com.costar.samples.core.VerifyItem
import com.costar.samples.core.VerifyState
import com.costar.samples.core.VerifyStatus
import com.costar.samples.core.Verification
import com.costar.samples.core.VerificationMedia
import com.costar.samples.ui.AudioPlaybackRow
import com.costar.samples.ui.Palette
import com.costar.samples.ui.Tone
import com.costar.samples.ui.VideoPlaybackView
import com.costar.samples.ui.card
import com.costar.samples.ui.chip
import com.costar.samples.ui.dp
import com.costar.samples.ui.hint
import com.costar.samples.ui.imagePreview
import com.costar.samples.ui.monoBlock
import com.costar.samples.ui.pageHeader
import com.costar.samples.ui.primaryButton
import com.costar.samples.ui.rounded
import com.costar.samples.ui.screen
import java.util.concurrent.atomic.AtomicBoolean

@SuppressLint("SetTextI18n")
internal class ItemPage : Activity() {

    private val domain: Domain by lazy {
        Domain.valueOf(intent.getStringExtra(EXTRA_DOMAIN) ?: Domain.DEVICE.name)
    }

    private val item: VerifyItem? by lazy {
        val id = intent.getStringExtra(EXTRA_ITEM_ID)
        VerifyCatalog.itemsOf(domain).firstOrNull { it.id == id }
    }

    private val handler = Handler(Looper.getMainLooper())

    private val settled = AtomicBoolean(false)

    private val running = AtomicBoolean(false)

    private lateinit var statusChip: TextView

    private lateinit var runButton: android.widget.Button

    private lateinit var linkNotice: TextView

    private lateinit var detailRow: LinearLayout

    private lateinit var detailText: TextView

    private lateinit var mediaHost: LinearLayout

    private var boundMedia: VerificationMedia? = null

    private var mediaRelease: (() -> Unit)? = null

    private val verificationListener: (String, VerifyState) -> Unit = { _, _ ->
        handler.post { render() }
    }

    private val watchdog = Runnable {
        if (item != null) {
            settle(VerifyStatus.FAIL, "等待回调超时(上限 ${item!!.timeoutMs} ms)")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (item == null) {
            finish()
            return
        }
        DemoSession.attach(this)
        setContentView(buildScreen())
        Verification.observe(verificationListener)
        render()
    }

    override fun onStart() {
        super.onStart()
        if (item != null) {
            render()
        }
    }

    override fun onStop() {
        item?.cleanup?.let { runCatching { it() } }
        releaseMedia()
        super.onStop()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        Verification.unobserve(verificationListener)
        super.onDestroy()
    }

private fun buildScreen(): View {
        val current = item ?: return View(this)
        return screen {
            addView(pageHeader(current.title, "单项验证", onBack = { finish() }))

            addView(featureDeclarationCard(domain))

            linkNotice = hint("").apply {
                textSize = 13f
                setPadding(dp(12), dp(10), dp(12), dp(10))
                background = rounded(Palette.WARN_BG, 10)
                setTextColor(Palette.WARN)
            }
            addView(linkNotice)

            detailRow = LinearLayout(this@ItemPage).apply {
                orientation = LinearLayout.VERTICAL
            }
            detailText = monoBlock("")
            mediaHost = LinearLayout(this@ItemPage).apply { orientation = LinearLayout.VERTICAL }
            detailRow.addView(detailText)
            detailRow.addView(mediaHost)

            val headerRow = LinearLayout(this@ItemPage).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            statusChip = chip(statusText(VerifyStatus.PENDING), Tone.MUTED)
            runButton = primaryButton("执行") { runItem() }
            headerRow.addView(statusChip)
            headerRow.addView(
                runButton,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { leftMargin = dp(10) }
            )

            val body = LinearLayout(this@ItemPage).apply {
                orientation = LinearLayout.VERTICAL
                addView(headerRow)
                addView(detailRow)
            }

            addView(card(current.title, body))
            addView(hint(current.howTo).apply { setPadding(dp(4), 0, dp(4), dp(12)) })

            addView(
                primaryButton("查看运行日志") {
                    startActivity(Intent(this@ItemPage, LogPage::class.java))
                }
            )
        }
    }

private fun runItem() {
        val current = item ?: return
        if (!DemoSession.linkAlive()) {
            settle(VerifyStatus.FAIL, "请先在「设备」页连接眼镜")
            return
        }
        if (!running.compareAndSet(false, true)) {
            return
        }
        settled.set(false)
        Verification.record(domain.name, current.id, VerifyStatus.RUNNING, "执行中")
        render()
        handler.removeCallbacks(watchdog)
        handler.postDelayed(watchdog, current.timeoutMs)
        runCatching {
            current.run { status, detail -> settle(status, detail) }
        }.onFailure { error ->
            settle(VerifyStatus.FAIL, "调用抛出异常: ${error.message}")
        }
    }

    private fun settle(status: VerifyStatus, detail: String) {
        val current = item ?: return
        if (!settled.compareAndSet(false, true)) {
            return
        }
        running.set(false)
        handler.removeCallbacks(watchdog)
        Verification.record(domain.name, current.id, status, detail)
        handler.post { render() }
    }

private fun render() {
        val current = item ?: return
        val alive = DemoSession.linkAlive()
        linkNotice.visibility = if (alive) View.GONE else View.VISIBLE
        if (!alive) {
            linkNotice.text = "请先在「设备」页连接眼镜后再执行。"
        }

        val state = Verification.stateOf(domain.name, current.id)
        val status = state?.status ?: VerifyStatus.PENDING
        statusChip.text = statusText(status)
        statusChip.applyTone(statusTone(status))

        val running = status == VerifyStatus.RUNNING
        runButton.text = if (status == VerifyStatus.PENDING) "执行" else "重新执行"
        runButton.isEnabled = alive && !running

        val detail = state?.detail.orEmpty()
        detailRow.visibility = if (status == VerifyStatus.PENDING && detail.isBlank()) View.GONE else View.VISIBLE
        detailText.text = detail

        bindMedia(Verification.mediaOf(domain.name, current.id))
    }

private fun bindMedia(latest: VerificationMedia?) {
        if (latest === boundMedia) {
            return
        }
        releaseMedia()
        boundMedia = latest
        if (latest == null) {
            return
        }
        mediaHost.addView(hint(latest.label).apply { setPadding(0, dp(10), 0, 0) })
        when (latest) {
            is VerificationMedia.Image -> {
                val preview = imagePreview(latest.file)
                mediaHost.addView(preview ?: hint("图片解码失败: ${latest.file.name}"))
            }

            is VerificationMedia.Audio -> {
                val playback = AudioPlaybackRow(this, latest.file)
                mediaRelease = playback::release
                mediaHost.addView(playback.view)
            }

            is VerificationMedia.Video -> {
                val playback = VideoPlaybackView(this, latest.file)
                mediaRelease = playback::release
                mediaHost.addView(playback.view)
            }
        }
    }

    private fun releaseMedia() {
        mediaRelease?.let { runCatching { it() } }
        mediaRelease = null
        boundMedia = null
        if (::mediaHost.isInitialized) {
            mediaHost.removeAllViews()
        }
    }

    companion object {

        private const val EXTRA_DOMAIN = "domain"

        private const val EXTRA_ITEM_ID = "itemId"

        fun intent(context: Context, domain: Domain, itemId: String): Intent =
            Intent(context, ItemPage::class.java)
                .putExtra(EXTRA_DOMAIN, domain.name)
                .putExtra(EXTRA_ITEM_ID, itemId)
    }
}