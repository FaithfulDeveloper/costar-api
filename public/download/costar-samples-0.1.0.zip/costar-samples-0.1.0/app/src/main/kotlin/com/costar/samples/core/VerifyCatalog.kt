package com.costar.samples.core

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.Base64
import com.costar.api.CostarAPI
import com.costar.api.core.CostarCallback
import com.costar.api.core.CostarError
import com.costar.api.core.CostarErrorCode
import com.costar.api.core.CostarResult
import com.costar.api.device.AudioOutput
import com.costar.api.device.AudioRoute
import com.costar.api.device.DeviceInfo
import com.costar.api.device.DisplayConfig
import com.costar.api.device.DisplayIcon
import com.costar.api.feature.Feature
import com.costar.api.feature.FeatureLevel
import com.costar.api.transfer.MediaType
import com.costar.api.transfer.SyncProgress
import com.costar.api.transfer.SyncRequest
import com.costar.api.vision.CameraConfig
import com.costar.api.vision.CameraFrame
import com.costar.api.vision.PhotoConfig
import com.costar.api.voice.AsrConfig
import com.costar.api.voice.AsrResult
import com.costar.api.voice.AudioCaptureConfig
import com.costar.api.voice.AudioStream
import com.costar.api.voice.TtsConfig
import com.costar.api.voice.WakeWordConfig
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

internal enum class Domain(
    val title: String,
    val features: List<Feature>
) {
    DEVICE(
        title = "设备管理",
        features = listOf(
            Feature.DEVICE_CONNECTION,
            Feature.DEVICE_INFO,
            Feature.DEVICE_AUDIO,
            Feature.DEVICE_DISPLAY,
            Feature.DEVICE_CUSTOM_DISPLAY,
            Feature.DEVICE_CAMERA_PARAM,
            Feature.DEVICE_FIRMWARE
        )
    ),
    VOICE(
        title = "语音",
        features = listOf(
            Feature.VOICE_TTS,
            Feature.VOICE_AUDIO_CAPTURE,
            Feature.VOICE_WAKE_WORD,
            Feature.VOICE_ASR
        )
    ),
    VISION(
        title = "视觉",
        features = listOf(Feature.VISION_CAMERA)
    ),
    TRANSFER(
        title = "传输",
        features = listOf(Feature.TRANSFER_WIFI_LINK, Feature.TRANSFER_MEDIA_SYNC)
    )
}

internal class VerifyGroup(val title: String, val items: List<VerifyItem>)

internal class VerifyItem(
    val id: String,
    val title: String,
    val howTo: String,
    val feature: Feature?,
    val timeoutMs: Long = 8_000L,
    val runnableWhenUnsupported: Boolean = false,
    val cleanup: (() -> Unit)? = null,
    val run: ((VerifyStatus, String) -> Unit) -> Unit
) {

    fun isExpected(): Boolean {
        if (runnableWhenUnsupported) return true
        val target = feature ?: return true
        return CostarAPI.features().level(target) != FeatureLevel.NONE
    }
}

internal object VerifyCatalog {

    private const val CAPTURE_TARGET_FRAMES = 20

    private const val STREAM_TARGET_FRAMES = 30

    private const val STREAM_FRAME_RATE = 15

    private const val WAV_HEADER_BYTES = 44

    private const val TTS_TEXT = "统一入口语音合成实测"

    private const val WAKE_KEYWORD = "演示唤醒"

    private const val CAMERA_ITEM_ID = "camera"

    private const val SNAPSHOT_ITEM_ID = "snapshot"

    private const val CAPTURE_ITEM_ID = "capture"

    private const val TTS_SPEED_ITEM_ID = "ttsSpeed"

    private const val TTS_SPEED_SLOW = 0.5f

    private const val TTS_SPEED_FAST = 2.0f

    private const val TTS_SPEED_GAP_MS = 4_000L

    private const val TTS_SPEAK_TIMEOUT_MS = 8_000L

    private const val VOLUME_VERIFY_FIRST_DELAY_MS = 900L

    private const val VOLUME_VERIFY_RETRY_DELAY_MS = 1_200L

    private const val VOLUME_VERIFY_ATTEMPTS = 2

    private const val DEVICE_INFO_READ_TIMEOUT_MS = 5_000L

    private const val ICON_NAME = "demo_icon"

    // 视图树 JSON:type 取类名、props 取属性、children 嵌子节点;需后续更新的节点在 props 中带 id。
    // 图标以 ImageView 节点引用,props.name 须与 sendIcons 下发的 DisplayIcon.name 一致,否则图标不会显示。
    private const val CUSTOM_DISPLAY_OPEN = """{"type":"LinearLayout","props":{"layout_width":"match_parent","layout_height":"match_parent","orientation":"vertical","gravity":"center","backgroundColor":"#CC000000"},"children":[{"type":"TextView","props":{"id":"costar_title","layout_width":"wrap_content","layout_height":"wrap_content","text":"Costar 自定义送显","textSize":"22sp","textColor":"#FFFFFFFF","gravity":"center"}},{"type":"TextView","props":{"id":"costar_body","layout_width":"wrap_content","layout_height":"wrap_content","text":"由统一入口下发","textSize":"16sp","textColor":"#FF00E5C0","gravity":"center","marginTop":"12dp"}},{"type":"ImageView","props":{"id":"costar_icon","layout_width":"48dp","layout_height":"48dp","name":"$ICON_NAME","marginTop":"16dp"}}]}"""

    private const val CUSTOM_DISPLAY_UPDATE = """[{"action":"update","id":"costar_body","props":{"text":"内容已更新","textColor":"#FFFF6B6B"}}]"""

    fun groupsOf(domain: Domain): List<VerifyGroup> = when (domain) {
        Domain.DEVICE -> listOf(
            VerifyGroup("设备信息", deviceInfoItems()),
            VerifyGroup("音频控制", audioItems()),
            VerifyGroup("显示控制", displayItems()),
            VerifyGroup("固件管理", firmwareItems()),
            VerifyGroup("相机参数", cameraParamItems())
        )
        Domain.VOICE -> listOf(VerifyGroup("语音", voiceItems()))
        Domain.VISION -> listOf(VerifyGroup("视觉", visionItems()))
        Domain.TRANSFER -> listOf(VerifyGroup("传输", transferItems()))
    }

    fun itemsOf(domain: Domain): List<VerifyItem> = groupsOf(domain).flatMap { it.items }

private fun deviceInfoItems(): List<VerifyItem> = listOf(
        VerifyItem(
            id = "info",
            title = "查询设备信息",
            howTo = "一次读取眼镜侧上报的全部状态字段,回调到达且字段有值即通过",
            feature = Feature.DEVICE_INFO,
            timeoutMs = 12_000L,
            run = { done ->
                CostarAPI.device().info(
                    callback(
                        onSuccess = { data ->
                            VerifyStatus.PASS to buildString {
                                append("设备名: ${data.deviceName}\n")
                                append("电量: ${data.batteryLevel}%  充电: ${data.charging}\n")
                                append("佩戴状态: ${data.wearingStatus}\n")
                                append("显示面板: ${data.devicePanel}\n")
                                append("亮度档位: ${data.brightness}  音量档位: ${data.volume}\n")
                                append("设备标识: ${data.deviceId}\n")
                                append("类型标识: ${data.deviceTypeId}\n")
                                append("系统版本: ${data.systemVersion}\n")
                                append("辅助服务版本: ${data.assistVersionName} (${data.assistVersionCode})")
                            }
                        },
                        done = done
                    )
                )
            }
        ),
        VerifyItem(
            id = "currentDevice",
            title = "读取当前设备描述",
            howTo = "统一入口当前记录的设备描述,包含厂商标识、型号与连接方式",
            feature = Feature.DEVICE_CONNECTION,
            run = { done ->
                val descriptor = DemoSession.currentDevice()
                if (descriptor == null) {
                    done(VerifyStatus.FAIL, "统一入口尚未记录当前设备")
                } else {
                    done(
                        VerifyStatus.PASS,
                        "厂商标识: ${descriptor.vendorId.name}\n" +
                            "型号: ${descriptor.model}\n" +
                            "固件版本: ${descriptor.firmwareVersion.ifBlank { "未上报" }}\n" +
                            "连接方式: ${descriptor.connectionType.name}"
                    )
                }
            }
        )
    )

// 固件升级会真实触发眼镜侧升级流程,不设为可执行项;这里只验证信息查询链路。
private fun firmwareItems(): List<VerifyItem> = listOf(
        VerifyItem(
            id = "firmwareInfo",
            title = "查询固件信息",
            howTo = "读取眼镜侧当前固件版本与是否有可用更新",
            feature = Feature.DEVICE_FIRMWARE,
            timeoutMs = 12_000L,
            run = { done ->
                when (val result = CostarAPI.device().firmware().info()) {
                    is CostarResult.Success -> done(
                        VerifyStatus.PASS,
                        "当前版本: ${result.data.currentVersion}\n" +
                            "最新版本: ${result.data.latestVersion ?: "未上报"}\n" +
                            "有可用更新: ${result.data.updateAvailable}"
                    )
                    is CostarResult.Failure -> done(VerifyStatus.FAIL, formatError(result.error))
                }
            }
        )
    )

// 相机参数归设备管理域:档位查询用于告知设备支持的分辨率列表,设置用于承载自定义分辨率。
private fun cameraParamItems(): List<VerifyItem> = listOf(
        VerifyItem(
            id = "cameraCapability",
            title = "查询相机参数档位",
            howTo = "读取设备支持的图像尺寸与帧率档位,回传非空即通过",
            feature = Feature.DEVICE_CAMERA_PARAM,
            run = { done ->
                when (val result = CostarAPI.device().cameraParam().capability()) {
                    is CostarResult.Success -> {
                        val capability = result.data
                        done(
                            VerifyStatus.PASS,
                            buildString {
                                append("支持的图像尺寸: ")
                                append(
                                    capability.supportedResolutions
                                        .joinToString(" / ") { "${it.width}×${it.height}" }
                                        .ifBlank { "未上报" }
                                )
                                append("\n支持的帧率: ")
                                append(
                                    capability.supportedFrameRates
                                        .joinToString(" / ") { "$it" }
                                        .ifBlank { "未上报" }
                                )
                            }
                        )
                    }

                    is CostarResult.Failure -> done(VerifyStatus.FAIL, formatError(result.error))
                }
            }
        ),
        VerifyItem(
            id = "cameraParamSet",
            title = "设置相机参数",
            howTo = "选定一个受支持的尺寸与帧率下发,再回读比对,一致才判定通过",
            feature = Feature.DEVICE_CAMERA_PARAM,
            run = { done ->
                val requested = CameraConfig(width = 1280, height = 720, frameRate = 30)
                when (val applied = CostarAPI.device().cameraParam().setConfig(requested)) {
                    is CostarResult.Failure -> done(VerifyStatus.FAIL, formatError(applied.error))
                    is CostarResult.Success -> when (val read = CostarAPI.device().cameraParam().config()) {
                        is CostarResult.Failure -> done(VerifyStatus.FAIL, formatError(read.error))
                        is CostarResult.Success -> {
                            val current = read.data
                            if (current == requested) {
                                done(
                                    VerifyStatus.PASS,
                                    "已设置 ${requested.width}×${requested.height} " +
                                        "@${requested.frameRate}fps,回读一致"
                                )
                            } else {
                                done(
                                    VerifyStatus.FAIL,
                                    "回读与设置不一致: 设置 ${requested.width}×${requested.height} " +
                                        "@${requested.frameRate}fps,回读 ${current.width}×${current.height} " +
                                        "@${current.frameRate}fps"
                                )
                            }
                        }
                    }
                }
            }
        )
    )

private fun displayItems(): List<VerifyItem> = listOf(
        VerifyItem(
            id = "brightness",
            title = "亮度下发(0.2 / 0.6 / 1.0)",
            howTo = "依次下发三档亮度,三档均返回成功且在眼镜侧看到明暗变化",
            feature = Feature.DEVICE_DISPLAY,
            run = { done ->
                val levels = listOf(0.2f, 0.6f, 1.0f)
                val failures = levels.mapNotNull { level ->
                    when (val result = CostarAPI.device().display().apply(DisplayConfig(brightness = level))) {
                        is CostarResult.Success -> null
                        is CostarResult.Failure -> "亮度 $level: ${formatError(result.error)}"
                    }
                }
                if (failures.isEmpty()) {
                    done(VerifyStatus.PASS, "三档亮度均已下发: 0.2 / 0.6 / 1.0")
                } else {
                    done(VerifyStatus.FAIL, failures.joinToString("\n"))
                }
            }
        ),
        VerifyItem(
            id = "customIcons",
            title = "下发图标资源",
            howTo = "图标为视图引用资源,下发后再开启引用它的视图才会显示",
            feature = Feature.DEVICE_CUSTOM_DISPLAY,
            timeoutMs = 12_000L,
            run = { done ->
                CostarAPI.device().customDisplay().sendIcons(
                    listOf(DisplayIcon(name = ICON_NAME, data = iconBase64())),
                    callback({ VerifyStatus.PASS to "已下发图标 $ICON_NAME" }, done)
                )
            }
        ),
        VerifyItem(
            id = "customOpen",
            title = "开启自定义送显",
            howTo = "推送视图片段,眼镜侧显示文案与上一步下发的图标",
            feature = Feature.DEVICE_CUSTOM_DISPLAY,
            timeoutMs = 12_000L,
            run = { done ->
                CostarAPI.device().customDisplay().open(
                    CUSTOM_DISPLAY_OPEN,
                    callback({ VerifyStatus.PASS to "已开启自定义送显" }, done)
                )
            }
        ),
        VerifyItem(
            id = "customUpdate",
            title = "更新自定义送显内容",
            howTo = "在已开启的视图上替换内容,需先执行「开启自定义送显」",
            feature = Feature.DEVICE_CUSTOM_DISPLAY,
            timeoutMs = 12_000L,
            run = { done ->
                CostarAPI.device().customDisplay().update(
                    CUSTOM_DISPLAY_UPDATE,
                    callback({ VerifyStatus.PASS to "内容已更新" }, done)
                )
            }
        ),
        VerifyItem(
            id = "customClose",
            title = "关闭自定义送显",
            howTo = "退出自定义显示状态,返回成功即通过",
            feature = Feature.DEVICE_CUSTOM_DISPLAY,
            run = { done ->
                report(CostarAPI.device().customDisplay().close(), "已关闭自定义送显", done)
            }
        )
    )

private fun audioItems(): List<VerifyItem> = listOf(
        VerifyItem(
            id = "routeQuery",
            title = "查询当前音频路由",
            howTo = "读取统一入口记录的输出通道,并回读眼镜侧上报的音量档位",
            feature = Feature.DEVICE_AUDIO,
            timeoutMs = 20_000L,
            run = { done ->
                CostarAPI.device().info(
                    object : CostarCallback<DeviceInfo> {
                        override fun onSuccess(data: DeviceInfo) {
                            when (val route = CostarAPI.device().audio().route()) {
                                is CostarResult.Success -> done(
                                    VerifyStatus.PASS,
                                    "眼镜上报音量档位: ${data.volume}\n" +
                                        "输出通道(统一入口记录): ${route.data.output.name}\n" +
                                        "统一入口记录音量: ${route.data.volume}"
                                )
                                is CostarResult.Failure -> done(VerifyStatus.FAIL, formatError(route.error))
                            }
                        }

                        override fun onError(error: CostarError) {
                            done(VerifyStatus.FAIL, "回读设备信息失败: ${formatError(error)}")
                        }
                    }
                )
            }
        ),
        volumeItem("volume20", "眼镜扬声器音量 20%", 20),
        volumeItem("volume60", "眼镜扬声器音量 60%", 60),
        volumeItem("volume100", "眼镜扬声器音量 100%", 100),
        VerifyItem(
            id = "routePhone",
            title = "切换到手机扬声器",
            howTo = "把声音切到手机侧,确认眼镜不再出声",
            feature = Feature.DEVICE_AUDIO,
            run = { done ->
                report(
                    CostarAPI.device().audio().setRoute(AudioRoute(AudioOutput.PHONE_SPEAKER, 0.5f)),
                    "已切换到手机扬声器",
                    done
                )
            }
        ),
        VerifyItem(
            id = "routeBluetooth",
            title = "切换到蓝牙通道",
            howTo = "把声音切到蓝牙通道,确认输出设备随之改变",
            feature = Feature.DEVICE_AUDIO,
            run = { done ->
                report(
                    CostarAPI.device().audio().setRoute(AudioRoute(AudioOutput.BLUETOOTH, 0.5f)),
                    "已切换到蓝牙通道",
                    done
                )
            }
        )
    )

    private fun volumeItem(id: String, title: String, percent: Int): VerifyItem = VerifyItem(
        id = id,
        title = title,
        howTo = "下发 $percent% 音量并回读眼镜上报值,二者一致才判定通过",
        feature = Feature.DEVICE_AUDIO,
        timeoutMs = 20_000L,
        run = { done ->
            val applied = CostarAPI.device().audio()
                .setRoute(AudioRoute(AudioOutput.GLASSES_SPEAKER, percent / 100f))
            if (applied is CostarResult.Failure) {
                done(VerifyStatus.FAIL, formatError(applied.error))
            } else {
                thread(name = "costar-volume-verify") {
                    val reported = awaitReportedVolume(percent)
                    when {
                        reported == null ->
                            done(VerifyStatus.FAIL, "已下发 $percent%,但未能回读眼镜上报音量")
                        reported == percent ->
                            done(VerifyStatus.PASS, "已下发 $percent%,眼镜上报 $reported")
                        else ->
                            done(
                                VerifyStatus.FAIL,
                                "下发 $percent%,眼镜上报 $reported,眼镜侧未按该档位生效"
                            )
                    }
                }
            }
        }
    )

private fun voiceItems(): List<VerifyItem> = listOf(
        VerifyItem(
            id = "tts",
            title = "文本播报",
            howTo = "下发一段文本,眼镜侧应发出声音,回调成功即通过",
            feature = Feature.VOICE_TTS,
            timeoutMs = 15_000L,
            run = { done ->
                CostarAPI.voice().tts().speak(
                    TTS_TEXT,
                    TtsConfig(),
                    callback({ VerifyStatus.PASS to "已播报: $TTS_TEXT" }, done)
                )
            }
        ),
        VerifyItem(
            id = TTS_SPEED_ITEM_ID,
            title = "播报语速对照($TTS_SPEED_SLOW / $TTS_SPEED_FAST)",
            howTo = "先后以 $TTS_SPEED_SLOW 倍与 $TTS_SPEED_FAST 倍语速播报同一段文本,眼镜侧应听出明显快慢差异",
            feature = Feature.VOICE_TTS,
            timeoutMs = 40_000L,
            run = { done ->
                thread(name = "costar-tts-speed") {
                    val slowError = speakAtSpeed(TTS_SPEED_SLOW)
                    if (slowError != null) {
                        done(VerifyStatus.FAIL, slowError)
                        return@thread
                    }
                    Thread.sleep(TTS_SPEED_GAP_MS)
                    val fastError = speakAtSpeed(TTS_SPEED_FAST)
                    if (fastError != null) {
                        done(VerifyStatus.FAIL, fastError)
                    } else {
                        done(
                            VerifyStatus.PASS,
                            "已按 $TTS_SPEED_SLOW 倍与 $TTS_SPEED_FAST 倍先后下发同一段文本\n" +
                                "请确认眼镜侧两遍的快慢差异"
                        )
                    }
                }
            }
        ),
        audioCaptureItem(
            id = CAPTURE_ITEM_ID,
            title = "录音采集($CAPTURE_TARGET_FRAMES 帧)",
            howTo = "开启录音通道后持续回传音频帧,收满 $CAPTURE_TARGET_FRAMES 帧自动停止,并可在结果区回放"
        ),
        VerifyItem(
            id = "wake",
            title = "唤醒事件",
            howTo = "启动监听后按眼镜侧方式触发唤醒(按键或唤醒词),收到一次事件即通过",
            feature = Feature.VOICE_WAKE_WORD,
            timeoutMs = 60_000L,
            cleanup = { runCatching { CostarAPI.voice().wake().stop() } },
            run = { done ->
                CostarAPI.voice().wake().start(WakeWordConfig(keywords = listOf(WAKE_KEYWORD))) { event ->
                    runCatching { CostarAPI.voice().wake().stop() }
                    done(
                        VerifyStatus.PASS,
                        "命中唤醒词: ${event.keyword}\n时间戳: ${event.timestamp}"
                    )
                }
            }
        ),
        VerifyItem(
            id = "asrGuard",
            title = "未声明能力的拦截行为",
            howTo = "调用语音识别并比对能力声明:声明为未支持时应返回 FEATURE_UNSUPPORTED,而非静默失败",
            feature = Feature.VOICE_ASR,
            runnableWhenUnsupported = true,
            timeoutMs = 12_000L,
            run = { done ->
                CostarAPI.voice().asr().start(
                    AsrConfig(),
                    object : CostarCallback<AsrResult> {
                        override fun onSuccess(data: AsrResult) {
                            val declared = CostarAPI.features().level(Feature.VOICE_ASR)
                            if (declared == FeatureLevel.NONE) {
                                done(
                                    VerifyStatus.FAIL,
                                    "能力声明为未支持,却返回了识别结果: ${data.text}"
                                )
                            } else {
                                done(
                                    VerifyStatus.PASS,
                                    "识别结果: ${data.text}\n置信度: ${data.confidence}"
                                )
                            }
                        }

                        override fun onError(error: CostarError) {
                            val declared = CostarAPI.features().level(Feature.VOICE_ASR)
                            if (error.code == CostarErrorCode.FEATURE_UNSUPPORTED) {
                                if (declared == FeatureLevel.NONE) {
                                    done(
                                        VerifyStatus.PASS,
                                        "已按能力协商拦下: ${error.code}\n${error.message}"
                                    )
                                } else {
                                    done(
                                        VerifyStatus.FAIL,
                                        "能力声明为 ${declared.name},却被以不支持拦下: ${error.message}"
                                    )
                                }
                            } else {
                                done(VerifyStatus.FAIL, formatError(error))
                            }
                        }
                    }
                )
            }
        )
    )

private fun visionItems(): List<VerifyItem> = listOf(
        VerifyItem(
            id = SNAPSHOT_ITEM_ID,
            title = "相机抓拍",
            howTo = "走拍照路径拍一张照片,回传的静态图像落到结果区供查看",
            feature = Feature.VISION_CAMERA,
            timeoutMs = 25_000L,
            run = { done ->
                CostarAPI.vision().camera().snapshot(
                    PhotoConfig(width = 640, height = 480),
                    callback({ data ->
                        val file = writeSnapshotImage(data.data)
                        if (file == null) {
                            VerifyStatus.PASS to "已拍得照片 ${data.data.size} 字节,但未写入结果目录"
                        } else {
                            Verification.publishMedia(
                                Domain.VISION.name,
                                SNAPSHOT_ITEM_ID,
                                VerificationMedia.Image(file, "抓拍照片 ${data.width}x${data.height}")
                            )
                            VerifyStatus.PASS to
                                "已拍得照片 ${data.data.size} 字节, ${data.width}x${data.height}\n文件: ${file.name}"
                        }
                    }, done)
                )
            }
        ),
        VerifyItem(
            id = CAMERA_ITEM_ID,
            title = "相机取流",
            howTo = "按能力声明取流:完全支持取连续帧并封装为可播放的录像,部分支持取单张;回传的是视频编码帧",
            feature = Feature.VISION_CAMERA,
            timeoutMs = 25_000L,
            cleanup = { runCatching { CostarAPI.vision().camera().stop() } },
            run = { done ->
                val level = CostarAPI.features().level(Feature.VISION_CAMERA)
                val target = if (level == FeatureLevel.PARTIAL) 1 else STREAM_TARGET_FRAMES
                val lock = Any()
                val collected = ArrayList<ByteArray>()
                val closed = AtomicBoolean(false)
                var firstFrame = ""

                CostarAPI.vision().camera().start(
                    CameraConfig(width = 640, height = 480, frameRate = STREAM_FRAME_RATE),
                    object : CostarCallback<CameraFrame> {
                        override fun onSuccess(data: CameraFrame) {
                            val count = synchronized(lock) {
                                if (closed.get()) return
                                if (collected.isEmpty()) {
                                    firstFrame =
                                        "首帧 ${data.data.size} 字节, ${data.width}x${data.height}"
                                }
                                collected.add(data.data)
                                collected.size
                            }
                            if (count < target) return
                            if (!closed.compareAndSet(false, true)) return
                            runCatching { CostarAPI.vision().camera().stop() }
                            val frames = synchronized(lock) { collected.toList() }
                            thread(name = "costar-stream-mux") {
                                val file = writeStreamVideo(frames, data.width, data.height)
                                if (file == null) {
                                    done(
                                        VerifyStatus.PASS,
                                        "声明等级 ${level.name},共收到 ${frames.size} 帧,录像封装失败\n$firstFrame"
                                    )
                                } else {
                                    Verification.publishMedia(
                                        Domain.VISION.name,
                                        CAMERA_ITEM_ID,
                                        VerificationMedia.Video(file, "取流录像 ${frames.size} 帧")
                                    )
                                    done(
                                        VerifyStatus.PASS,
                                        "声明等级 ${level.name},共收到 ${frames.size} 帧\n" +
                                            "$firstFrame\n文件: ${file.name}"
                                    )
                                }
                            }
                        }

                        override fun onError(error: CostarError) {
                            if (closed.compareAndSet(false, true)) {
                                done(VerifyStatus.FAIL, formatError(error))
                            }
                        }
                    }
                )
            }
        ),
        VerifyItem(
            id = "cameraStop",
            title = "停止取流",
            howTo = "下发停止指令,确认取流通道被回收且不再有帧回传",
            feature = Feature.VISION_CAMERA,
            run = { done ->
                val result = runCatching { CostarAPI.vision().camera().stop() }
                if (result.isSuccess) {
                    done(VerifyStatus.PASS, "已下发停止取流")
                } else {
                    done(VerifyStatus.FAIL, "停止取流失败: ${result.exceptionOrNull()?.message}")
                }
            }
        )
    )

private fun transferItems(): List<VerifyItem> = listOf(
        VerifyItem(
            id = "wifiOpen",
            title = "打开 Wi-Fi 通道",
            howTo = "开启手机与眼镜之间的高速通道,通道打开回调到达即通过",
            feature = Feature.TRANSFER_WIFI_LINK,
            timeoutMs = 45_000L,
            run = { done ->
                CostarAPI.transfer().wifiLink().open(
                    callback({ VerifyStatus.PASS to "Wi-Fi 通道已打开" }, done)
                )
            }
        ),
        VerifyItem(
            id = "pending",
            title = "查询待同步件数",
            howTo = "读取眼镜侧待同步的音频、图片、视频件数",
            feature = Feature.TRANSFER_MEDIA_SYNC,
            timeoutMs = 15_000L,
            run = { done ->
                CostarAPI.transfer().media().pending(
                    callback({ media ->
                        VerifyStatus.PASS to buildString {
                            append("音频: ${media.audio}\n")
                            append("图片: ${media.picture}\n")
                            append("视频: ${media.video}\n")
                            append("合计: ${media.total}")
                        }
                    }, done)
                )
            }
        ),
        VerifyItem(
            id = "sync",
            title = "同步媒体并落盘",
            howTo = "把待同步的图片、视频、音频落到应用外部目录,并核对落盘目录内确有文件",
            feature = Feature.TRANSFER_MEDIA_SYNC,
            timeoutMs = 120_000L,
            cleanup = { runCatching { CostarAPI.transfer().media().stop() } },
            run = { done ->
                val savePath = DemoSession.syncDir()
                if (savePath.isBlank()) {
                    done(VerifyStatus.FAIL, "未能取得落盘目录")
                } else {
                    val synced = mutableListOf<String>()
                    CostarAPI.transfer().media().sync(
                        SyncRequest(
                            savePath = savePath,
                            types = setOf(MediaType.PICTURE, MediaType.VIDEO, MediaType.AUDIO)
                        ),
                        object : CostarCallback<SyncProgress> {
                            override fun onSuccess(data: SyncProgress) {
                                data.syncedFile?.takeIf { it.isNotBlank() }?.let { synced.add(it) }
                                if (!data.finished) return
                                val landed = File(savePath).listFiles()
                                    ?.filter { it.isFile }
                                    ?.sortedBy { it.name }
                                    .orEmpty()
                                when {
                                    synced.isEmpty() -> done(
                                        VerifyStatus.PASS,
                                        "本批同步结束,眼镜侧没有待同步文件\n目录: $savePath"
                                    )

                                    landed.isEmpty() -> done(
                                        VerifyStatus.FAIL,
                                        "同步结束,但落盘目录内没有文件,文件可能被写到了目录之外\n目录: $savePath" +
                                            synced.joinToString("", prefix = "\n") { "· 回调文件名: $it" }
                                    )

                                    else -> done(
                                        VerifyStatus.PASS,
                                        "本批同步结束,落盘 ${landed.size} 个文件\n目录: $savePath" +
                                            landed.joinToString("", prefix = "\n") {
                                                "· ${it.name}  ${it.length() / 1024} KB"
                                            }
                                    )
                                }
                            }

                            override fun onError(error: CostarError) {
                                done(VerifyStatus.FAIL, formatError(error))
                            }
                        }
                    )
                }
            }
        ),
        VerifyItem(
            id = "wifiClose",
            title = "关闭 Wi-Fi 通道",
            howTo = "关闭高速通道,返回成功即通过",
            feature = Feature.TRANSFER_WIFI_LINK,
            run = { done ->
                report(CostarAPI.transfer().wifiLink().close(), "Wi-Fi 通道已关闭", done)
            }
        )
    )

private fun audioCaptureItem(
        id: String,
        title: String,
        howTo: String
    ): VerifyItem = VerifyItem(
        id = id,
        title = title,
        howTo = howTo,
        feature = Feature.VOICE_AUDIO_CAPTURE,
        timeoutMs = 25_000L,
        cleanup = { runCatching { CostarAPI.voice().capture().stop() } },
        run = { done ->
            val config = AudioCaptureConfig()
            val pcm = ByteArrayOutputStream()
            var frames = 0
            var firstFrame = ""
            CostarAPI.voice().capture().start(
                config,
                object : CostarCallback<AudioStream> {
                    override fun onSuccess(data: AudioStream) {
                        if (frames == 0) {
                            firstFrame = "首帧 ${data.data.size} 字节, ${data.sampleRate}Hz / ${data.channels} 声道"
                        }
                        pcm.write(data.data)
                        frames++
                        if (frames >= CAPTURE_TARGET_FRAMES) {
                            runCatching { CostarAPI.voice().capture().stop() }
                            val file = writeCaptureAudio(
                                pcm.toByteArray(),
                                config.sampleRateHz,
                                config.channels
                            )
                            var detail = "共收到 $frames 帧\n$firstFrame"
                            if (file != null) {
                                Verification.publishMedia(
                                    Domain.VOICE.name,
                                    id,
                                    VerificationMedia.Audio(
                                        file,
                                        "采集结果 $frames 帧,${config.sampleRateHz}Hz / ${config.channels} 声道"
                                    )
                                )
                                detail += "\n录音文件: ${file.name}"
                            }
                            done(VerifyStatus.PASS, detail)
                        }
                    }

                    override fun onError(error: CostarError) {
                        done(VerifyStatus.FAIL, formatError(error))
                    }
                }
            )
        }
    )

private fun speakAtSpeed(speed: Float): String? {
        val latch = CountDownLatch(1)
        var error: String? = null
        CostarAPI.voice().tts().speak(
            TTS_TEXT,
            TtsConfig(speed = speed),
            object : CostarCallback<Unit> {
                override fun onSuccess(data: Unit) = latch.countDown()

                override fun onError(e: CostarError) {
                    error = formatError(e)
                    latch.countDown()
                }
            }
        )
        return if (latch.await(TTS_SPEAK_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
            error
        } else {
            "以 $speed 倍语速下发播报超时"
        }
    }

    private fun awaitReportedVolume(percent: Int): Int? {
        var last: Int? = null
        repeat(VOLUME_VERIFY_ATTEMPTS) { attempt ->
            Thread.sleep(if (attempt == 0) VOLUME_VERIFY_FIRST_DELAY_MS else VOLUME_VERIFY_RETRY_DELAY_MS)
            last = readReportedVolume() ?: return@repeat
            if (last == percent) return last
        }
        return last
    }

    private fun readReportedVolume(): Int? {
        val latch = CountDownLatch(1)
        var value: Int? = null
        CostarAPI.device().info(
            object : CostarCallback<DeviceInfo> {
                override fun onSuccess(data: DeviceInfo) {
                    value = data.volume
                    latch.countDown()
                }

                override fun onError(error: CostarError) {
                    latch.countDown()
                }
            }
        )
        latch.await(DEVICE_INFO_READ_TIMEOUT_MS, TimeUnit.MILLISECONDS)
        return value
    }

private fun <T> callback(
        onSuccess: (T) -> Pair<VerifyStatus, String>,
        done: (VerifyStatus, String) -> Unit
    ): CostarCallback<T> = object : CostarCallback<T> {
        override fun onSuccess(data: T) {
            val (status, detail) = onSuccess(data)
            done(status, detail)
        }

        override fun onError(error: CostarError) {
            done(VerifyStatus.FAIL, formatError(error))
        }
    }

    private fun report(
        result: CostarResult<Unit>,
        successDetail: String,
        done: (VerifyStatus, String) -> Unit
    ) {
        when (result) {
            is CostarResult.Success -> done(VerifyStatus.PASS, successDetail)
            is CostarResult.Failure -> done(VerifyStatus.FAIL, formatError(result.error))
        }
    }

    private fun formatError(error: CostarError): String = buildString {
        append("${error.code.name}: ${error.message}")
        error.vendorDetail?.takeIf { it.isNotBlank() }?.let { append("\n底层原始信息: $it") }
    }

private fun writeSnapshotImage(bytes: ByteArray): File? {
        if (bytes.isEmpty()) return null
        val dir = DemoSession.mediaDir()
        if (dir.isBlank()) return null
        val file = File(dir, "camera_snapshot_${System.currentTimeMillis()}.jpg")
        return runCatching {
            file.outputStream().use { it.write(bytes) }
            file
        }.getOrNull()
    }

    private fun writeStreamVideo(frames: List<ByteArray>, width: Int, height: Int): File? {
        val dir = DemoSession.mediaDir()
        if (dir.isBlank()) return null
        val file = File(dir, "camera_stream_${System.currentTimeMillis()}.mp4")
        return if (StreamVideoWriter.write(frames, width, height, STREAM_FRAME_RATE, file)) {
            file
        } else {
            null
        }
    }

    private fun writeCaptureAudio(pcm: ByteArray, sampleRateHz: Int, channels: Int): File? {
        if (pcm.isEmpty()) return null
        val dir = DemoSession.mediaDir()
        if (dir.isBlank()) return null
        val file = File(dir, "voice_capture_${System.currentTimeMillis()}.wav")
        return runCatching {
            file.outputStream().use { it.write(pcmToWav(pcm, sampleRateHz, channels)) }
            file
        }.getOrNull()
    }

    private fun pcmToWav(pcm: ByteArray, sampleRateHz: Int, channels: Int): ByteArray {
        val bitsPerSample = 16
        val safeRate = if (sampleRateHz > 0) sampleRateHz else 16_000
        val safeChannels = if (channels > 0) channels else 1
        val blockAlign = safeChannels * bitsPerSample / 8
        val buffer = ByteBuffer.allocate(WAV_HEADER_BYTES + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
        buffer.put("RIFF".toByteArray(Charsets.US_ASCII))
        buffer.putInt(WAV_HEADER_BYTES - 8 + pcm.size)
        buffer.put("WAVE".toByteArray(Charsets.US_ASCII))
        buffer.put("fmt ".toByteArray(Charsets.US_ASCII))
        buffer.putInt(16)
        buffer.putShort(1.toShort())
        buffer.putShort(safeChannels.toShort())
        buffer.putInt(safeRate)
        buffer.putInt(safeRate * blockAlign)
        buffer.putShort(blockAlign.toShort())
        buffer.putShort(bitsPerSample.toShort())
        buffer.put("data".toByteArray(Charsets.US_ASCII))
        buffer.putInt(pcm.size)
        buffer.put(pcm)
        return buffer.array()
    }

    private fun iconBase64(): String {
        val size = 48
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawCircle(
            size / 2f,
            size / 2f,
            size / 2f - 2f,
            Paint().apply {
                color = Color.parseColor("#0FA69C")
                isAntiAlias = true
            }
        )
        canvas.drawCircle(
            size / 2f,
            size / 2f,
            size / 4f,
            Paint().apply {
                color = Color.WHITE
                isAntiAlias = true
            }
        )
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
        bitmap.recycle()
        return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }
}
