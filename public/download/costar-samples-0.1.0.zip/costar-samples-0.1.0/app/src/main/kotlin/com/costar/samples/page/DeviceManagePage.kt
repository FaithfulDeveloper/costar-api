package com.costar.samples.page

import com.costar.samples.core.Domain

internal class DeviceManagePage : VerificationPage() {
    override val domain: Domain = Domain.DEVICE
}