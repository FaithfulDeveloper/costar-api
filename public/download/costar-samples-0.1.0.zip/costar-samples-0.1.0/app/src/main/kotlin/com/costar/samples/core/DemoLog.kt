package com.costar.samples.core

import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

internal object DemoLog {

    private const val TAG = "CostarDemo"
    private const val MAX_LINES = 600

    private val formatter = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    private val lines = ArrayDeque<String>()

    private val listeners = mutableListOf<(List<String>) -> Unit>()

    fun append(line: String) {
        Log.d(TAG, line)
        val snapshot: List<String>
        val targets: List<(List<String>) -> Unit>
        synchronized(this) {
            lines.addLast("${formatter.format(Date())}  $line")
            while (lines.size > MAX_LINES) {
                lines.removeFirst()
            }
            snapshot = lines.toList()
            targets = listeners.toList()
        }
        targets.forEach { it(snapshot) }
    }

    fun snapshot(): List<String> = synchronized(this) { lines.toList() }

    fun last(): String? = synchronized(this) { lines.lastOrNull() }

    fun clear() {
        val targets: List<(List<String>) -> Unit>
        synchronized(this) {
            lines.clear()
            targets = listeners.toList()
        }
        targets.forEach { it(emptyList()) }
    }

    fun observe(listener: (List<String>) -> Unit) {
        synchronized(this) { listeners.add(listener) }
    }

    fun unobserve(listener: (List<String>) -> Unit) {
        synchronized(this) { listeners.remove(listener) }
    }
}
