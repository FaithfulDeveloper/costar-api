package com.costar.samples.page

import android.app.Activity
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.costar.api.CostarAPI
import com.costar.api.feature.FeatureLevel
import com.costar.samples.core.DemoSession
import com.costar.samples.core.Domain
import com.costar.samples.core.VerifyCatalog
import com.costar.samples.core.VerifyGroup
import com.costar.samples.core.VerifyItem
import com.costar.samples.core.VerifyState
import com.costar.samples.core.VerifyStatus
import com.costar.samples.core.Verification
import com.costar.samples.ui.Palette
import com.costar.samples.ui.Tone
import com.costar.samples.ui.card
import com.costar.samples.ui.chip
import com.costar.samples.ui.divider
import com.costar.samples.ui.dp
import com.costar.samples.ui.hint
import com.costar.samples.ui.navRow
import com.costar.samples.ui.pageHeader
import com.costar.samples.ui.primaryButton
import com.costar.samples.ui.rounded
import com.costar.samples.ui.screen

@SuppressLint("SetTextI18n")
internal abstract class VerificationPage : Activity() {

    protected abstract val domain: Domain

    protected open val groupTitle: String? = null

    private val handler = Handler(Looper.getMainLooper())

    private val groups: List<VerifyGroup> by lazy { VerifyCatalog.groupsOf(domain) }

    private val currentGroup: VerifyGroup? by lazy {
        val title = groupTitle ?: return@lazy null
        groups.firstOrNull { it.title == title }
    }

    private val items: List<VerifyItem> by lazy {
        currentGroup?.items ?: if (groups.size == 1) groups.single().items else emptyList()
    }

    private val subGroups: List<VerifyGroup> by lazy { if (items.isEmpty()) groups else emptyList() }

    private lateinit var itemContainer: LinearLayout

    private lateinit var progressChip: TextView

    private lateinit var linkNotice: TextView

    private val verificationListener: (String, VerifyState) -> Unit = { _, _ ->
        handler.post { render() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DemoSession.attach(this)
        setContentView(buildScreen())
        Verification.observe(verificationListener)
        render()
    }

    override fun onStart() {
        super.onStart()
        render()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        Verification.unobserve(verificationListener)
        super.onDestroy()
    }

private fun buildScreen(): View = screen {
        addView(pageHeader(currentGroup?.title ?: domain.title, null, onBack = { finish() }))

        if (currentGroup == null) {
            addView(featureDeclarationCard(domain))
        }

        linkNotice = hint("").apply {
            textSize = 13f
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(Palette.WARN_BG, 10)
            setTextColor(Palette.WARN)
        }
        addView(linkNotice)

        itemContainer = LinearLayout(this@VerificationPage).apply {
            orientation = LinearLayout.VERTICAL
        }
        addView(card("检查项", itemContainer))

        val progressRow = LinearLayout(this@VerificationPage).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(16))
        }
        progressChip = chip("已验证 0/0", Tone.MUTED)
        progressRow.addView(progressChip)
        addView(progressRow)

        extraSections(this)

        addView(
            primaryButton("查看运行日志") {
                startActivity(Intent(this@VerificationPage, LogPage::class.java))
            }
        )
    }

    protected open fun extraSections(container: LinearLayout) = Unit

private fun render() {
        val alive = DemoSession.linkAlive()
        linkNotice.visibility = if (alive) View.GONE else View.VISIBLE
        if (!alive) {
            linkNotice.text = "请先在「设备」页连接眼镜后再进行检查。"
        }

        itemContainer.removeAllViews()
        if (subGroups.isEmpty()) {
            items.forEachIndexed { index, item ->
                itemContainer.addView(itemRow(item, alive))
                if (index < items.lastIndex) itemContainer.addView(divider())
            }
        } else {
            subGroups.forEachIndexed { index, group ->
                itemContainer.addView(groupRow(group, alive))
                if (index < subGroups.lastIndex) itemContainer.addView(divider())
            }
        }

        val progressItems = if (items.isEmpty()) groups.flatMap { it.items } else items
        val (passed, expected) = Verification.progress(domain, progressItems)
        progressChip.text = "已验证 $passed/$expected"
        progressChip.applyTone(if (expected > 0 && passed == expected) Tone.OK else Tone.MUTED)
    }

    private fun itemRow(item: VerifyItem, alive: Boolean): LinearLayout {
        val state = Verification.stateOf(domain.name, item.id)
        val status = state?.status ?: VerifyStatus.PENDING
        val expected = item.isExpected()
        val enabled = alive && expected
        val subtitle = when {
            !expected -> "本机未声明 ${item.feature?.name}"
            !alive -> "需要先连接眼镜"
            else -> statusText(status)
        }
        return navRow(item.title, subtitle, statusTone(status), enabled) {
            when {
                !alive -> toast("请先连接眼镜")
                !expected -> toast("本机未声明该能力")
                else -> startActivity(ItemPage.intent(this, domain, item.id))
            }
        }
    }

    private fun groupRow(group: VerifyGroup, alive: Boolean): LinearLayout {
        val (passed, expected) = Verification.progress(domain, group.items)
        val declared = expected > 0
        val enabled = alive && declared
        val subtitle = when {
            !declared -> "本机未声明"
            !alive -> "需要先连接眼镜"
            else -> "已验证 $passed/$expected"
        }
        return navRow(group.title, subtitle, Tone.MUTED, enabled) {
            when {
                !alive -> toast("请先连接眼镜")
                !declared -> toast("本机未声明该能力")
                else -> startActivity(SubGroupPage.intent(this, domain, group.title))
            }
        }
    }

    private fun toast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }
}

@SuppressLint("SetTextI18n")
internal fun Context.featureDeclarationCard(domain: Domain): LinearLayout {
    val declarations = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    domain.features.forEach { feature ->
        val level = CostarAPI.features().level(feature)
        declarations.addView(
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(4), 0, dp(4))
                addView(
                    TextView(this@featureDeclarationCard).apply {
                        text = feature.name
                        textSize = 13f
                        setTextColor(Palette.TEXT)
                        layoutParams = LinearLayout.LayoutParams(
                            0,
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                            1f
                        )
                    }
                )
                addView(chip(levelText(level), levelTone(level)))
            }
        )
    }
    return card("能力声明", declarations)
}

internal fun statusText(status: VerifyStatus): String = when (status) {
    VerifyStatus.PENDING -> "未验证"
    VerifyStatus.RUNNING -> "执行中"
    VerifyStatus.PASS -> "通过"
    VerifyStatus.FAIL -> "失败"
    VerifyStatus.UNSUPPORTED -> "未声明"
}

internal fun statusTone(status: VerifyStatus): Tone = when (status) {
    VerifyStatus.PENDING -> Tone.MUTED
    VerifyStatus.RUNNING -> Tone.BRAND
    VerifyStatus.PASS -> Tone.OK
    VerifyStatus.FAIL -> Tone.DANGER
    VerifyStatus.UNSUPPORTED -> Tone.MUTED
}

internal fun levelText(level: FeatureLevel): String = when (level) {
    FeatureLevel.FULL -> "完全支持"
    FeatureLevel.PARTIAL -> "部分支持"
    FeatureLevel.NONE -> "未声明"
}

internal fun levelTone(level: FeatureLevel): Tone = when (level) {
    FeatureLevel.FULL -> Tone.OK
    FeatureLevel.PARTIAL -> Tone.WARN
    FeatureLevel.NONE -> Tone.MUTED
}

internal fun TextView.applyTone(tone: Tone) {
    setTextColor(tone.fg)
    background = context.rounded(tone.bg, 6)
}