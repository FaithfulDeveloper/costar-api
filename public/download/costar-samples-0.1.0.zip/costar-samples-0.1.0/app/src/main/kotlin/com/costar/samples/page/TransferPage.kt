package com.costar.samples.page

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.costar.samples.core.DemoSession
import com.costar.samples.core.Domain
import com.costar.samples.ui.AudioPlaybackRow
import com.costar.samples.ui.Palette
import com.costar.samples.ui.VideoPlaybackView
import com.costar.samples.ui.card
import com.costar.samples.ui.dangerButton
import com.costar.samples.ui.dp
import com.costar.samples.ui.hint
import com.costar.samples.ui.imagePreview
import com.costar.samples.ui.secondaryButton
import java.io.File

@SuppressLint("SetTextI18n")
internal class TransferPage : VerificationPage() {

    override val domain: Domain = Domain.TRANSFER

    private lateinit var mediaContainer: LinearLayout

    private lateinit var mediaSubtitle: TextView

    private val playbackResources = mutableListOf<() -> Unit>()

    override fun extraSections(container: LinearLayout) {
        mediaContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        mediaSubtitle = hint("")
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(secondaryButton("刷新") { renderMedia() })
            addView(
                dangerButton("清空") { confirmClear() },
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { leftMargin = dp(8) }
            )
        }
        container.addView(
            card(
                "已同步媒体",
                mediaContainer,
                headerAction = actions
            )
        )
        container.addView(mediaSubtitle)
        renderMedia()
    }

    private fun confirmClear() {
        val dirPath = DemoSession.syncDir()
        if (dirPath.isBlank()) {
            Toast.makeText(this, "尚未取得落盘目录", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("清空已同步媒体")
            .setMessage("将删除 $dirPath 下的全部文件与子目录,此操作不可恢复。")
            .setNegativeButton("取消", null)
            .setPositiveButton("清空") { _, _ -> clearMedia(File(dirPath)) }
            .show()
    }

    private fun clearMedia(dir: File) {
        releasePlayback()
        val removed = runCatching {
            dir.listFiles()?.count { it.deleteRecursively() } ?: 0
        }.getOrDefault(0)
        Toast.makeText(this, "已清空 $removed 项", Toast.LENGTH_SHORT).show()
        renderMedia()
    }

    override fun onStart() {
        super.onStart()
        if (::mediaContainer.isInitialized) {
            renderMedia()
        }
    }

    override fun onStop() {
        releasePlayback()
        super.onStop()
    }

    private fun releasePlayback() {
        playbackResources.forEach { runCatching { it() } }
        playbackResources.clear()
    }

    private fun renderMedia() {
        releasePlayback()
        mediaContainer.removeAllViews()
        val dirPath = DemoSession.syncDir()
        val entries = if (dirPath.isBlank()) {
            emptyList()
        } else {
            File(dirPath).listFiles()?.sortedBy { it.name } ?: emptyList()
        }
        val files = entries.filter { it.isFile }
        val dirs = entries.filter { it.isDirectory }

        mediaSubtitle.text = if (dirPath.isBlank()) {
            "未取得落盘目录"
        } else {
            buildString {
                append("目录: $dirPath,共 ${files.size} 个文件")
                if (dirs.isNotEmpty()) {
                    append(",另有 ${dirs.size} 个子目录")
                }
            }
        }

        if (files.isEmpty()) {
            if (dirs.isEmpty()) {
                mediaContainer.addView(hint("暂无文件。执行「同步媒体并落盘」后再刷新。"))
            } else {
                mediaContainer.addView(
                    hint(
                        "本层没有文件,仅含子目录: " + dirs.joinToString("、") { it.name } +
                            "。请展开子目录查看,或重新执行「同步媒体并落盘」。"
                    )
                )
            }
            return
        }
        files.forEach { file -> mediaContainer.addView(mediaRow(file)) }
    }

    private fun mediaRow(file: File): View = when (mediaKindOf(file)) {
        MediaKind.AUDIO -> {
            val playback = AudioPlaybackRow(this, file)
            playbackResources.add(playback::release)
            playback.view
        }

        MediaKind.VIDEO -> {
            val playback = VideoPlaybackView(this, file)
            playbackResources.add(playback::release)
            playback.view
        }

        MediaKind.IMAGE ->
            nameRow(file, imagePreview(file) ?: hint("图片解码失败: ${file.name}"))

        MediaKind.UNKNOWN -> nameRow(file, null)
    }

    private fun nameRow(file: File, extra: View?): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(0, dp(8), 0, dp(8))
        addView(
            TextView(this@TransferPage).apply {
                text = "${file.name}   ${file.length() / 1024} KB"
                textSize = 13f
                setTextColor(Palette.TEXT)
            }
        )
        if (extra != null) {
            addView(extra)
        }
    }

    private fun mediaKindOf(file: File): MediaKind {
        val name = file.name.lowercase()
        when {
            AUDIO_SUFFIXES.any { name.endsWith(it) } -> return MediaKind.AUDIO
            VIDEO_SUFFIXES.any { name.endsWith(it) } -> return MediaKind.VIDEO
            IMAGE_SUFFIXES.any { name.endsWith(it) } -> return MediaKind.IMAGE
        }
        return sniffKind(file)
    }

    private fun sniffKind(file: File): MediaKind {
        val header = runCatching {
            file.inputStream().use { stream -> ByteArray(SNIFF_BYTES).also { stream.read(it) } }
        }.getOrNull() ?: return MediaKind.UNKNOWN
        if (header.size < SNIFF_BYTES) return MediaKind.UNKNOWN
        fun byteAt(index: Int, char: Char) = header[index] == char.code.toByte()
        return when {
            header[0] == 0xFF.toByte() && header[1] == 0xD8.toByte() && header[2] == 0xFF.toByte() ->
                MediaKind.IMAGE
            header[0] == 0x89.toByte() && byteAt(1, 'P') && byteAt(2, 'N') && byteAt(3, 'G') ->
                MediaKind.IMAGE
            byteAt(4, 'f') && byteAt(5, 't') && byteAt(6, 'y') && byteAt(7, 'p') ->
                MediaKind.VIDEO
            byteAt(0, 'R') && byteAt(1, 'I') && byteAt(2, 'F') && byteAt(3, 'F') &&
                byteAt(8, 'W') && byteAt(9, 'A') && byteAt(10, 'V') && byteAt(11, 'E') ->
                MediaKind.AUDIO
            byteAt(0, 'I') && byteAt(1, 'D') && byteAt(2, '3') ->
                MediaKind.AUDIO
            else -> MediaKind.UNKNOWN
        }
    }

    private enum class MediaKind { AUDIO, VIDEO, IMAGE, UNKNOWN }

    private companion object {
        val AUDIO_SUFFIXES = listOf(".wav", ".mp3", ".m4a", ".aac", ".pcm")
        val VIDEO_SUFFIXES = listOf(".mp4", ".mov", ".3gp", ".mkv", ".hevc", ".h265")
        val IMAGE_SUFFIXES = listOf(".jpg", ".jpeg", ".png", ".webp")

        const val SNIFF_BYTES = 16
    }
}
