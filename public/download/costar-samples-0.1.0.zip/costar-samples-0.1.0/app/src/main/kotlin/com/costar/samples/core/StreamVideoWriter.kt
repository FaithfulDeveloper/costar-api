package com.costar.samples.core

import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaMuxer
import android.util.Log
import java.io.File
import java.nio.ByteBuffer

// 底层回传 Annex B 形式的 HEVC 码流:参数集写入 csd-0,图像数据保持起始码分隔逐帧写入。
// 图像数据不能提前加 4 字节长度前缀——封装器会再包一层,解码器识别不出画面(黑屏)。
internal object StreamVideoWriter {

    private const val TAG = "CostarStream"

    private const val MIME_HEVC = "video/hevc"

    private const val NAL_HEADER_BYTES = 2

    private const val NAL_TYPE_VPS = 32

    private const val NAL_TYPE_SPS = 33

    private const val NAL_TYPE_PPS = 34

    private const val NAL_TYPE_IDR_W_RADL = 19

    private const val NAL_TYPE_IDR_N_LP = 20

    // 参数集须按 VPS、SPS、PPS 的顺序提供。
    private val PARAMETER_SET_TYPES = listOf(NAL_TYPE_VPS, NAL_TYPE_SPS, NAL_TYPE_PPS)

    private val START_CODE = byteArrayOf(0, 0, 0, 1)

    fun write(
        frames: List<ByteArray>,
        width: Int,
        height: Int,
        frameRate: Int,
        target: File
    ): Boolean {
        if (frames.size < 2) {
            Log.d(TAG, "封装中止: 帧数不足 ${frames.size}")
            return false
        }

        val parameterSets = frames.flatMap { splitNalUnits(it) }.filter { it.isParameterSet() }
        val config = annexBConfig(parameterSets)
        if (config == null) {
            Log.d(TAG, "封装中止: VPS/SPS/PPS 不全,参数集=${parameterSets.groupingBy { it.type }.eachCount()}")
            return false
        }

        val frameIntervalUs = 1_000_000L / frameRate.coerceAtLeast(1)
        var muxer: MediaMuxer? = null
        return try {
            val format = MediaFormat.createVideoFormat(MIME_HEVC, width, height).apply {
                setInteger(MediaFormat.KEY_FRAME_RATE, frameRate.coerceAtLeast(1))
                setByteBuffer("csd-0", config)
            }

            muxer = MediaMuxer(target.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val active = muxer
            val track = active.addTrack(format)
            active.start()

            var written = 0
            frames.forEach { frame ->
                // 访问单元只保留图像数据:参数集已由 csd-0 声明,重复写入会使部分解码器失败。
                val picture = splitNalUnits(frame).filter { !it.isParameterSet() }
                if (picture.isEmpty()) return@forEach

                val payload = annexBAccessUnit(picture)
                val keyFrame = picture.any {
                    it.type == NAL_TYPE_IDR_W_RADL || it.type == NAL_TYPE_IDR_N_LP
                }
                val bufferInfo = MediaCodec.BufferInfo().apply {
                    set(
                        0,
                        payload.remaining(),
                        written * frameIntervalUs,
                        if (written == 0 || keyFrame) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    )
                }
                active.writeSampleData(track, payload, bufferInfo)
                written++
            }

            if (written == 0) {
                Log.d(TAG, "封装中止: 无图像数据 NAL")
                false
            } else {
                active.stop()
                Log.d(TAG, "封装成功: 写入 $written 帧 → ${target.name}(${target.length()} 字节)")
                true
            }
        } catch (t: Throwable) {
            Log.d(TAG, "封装异常: ${t.javaClass.simpleName}: ${t.message}")
            false
        } finally {
            runCatching { muxer?.release() }
        }
    }

private fun annexBConfig(parameterSets: List<NalUnit>): ByteBuffer? {
        val ordered = ArrayList<NalUnit>(PARAMETER_SET_TYPES.size)
        PARAMETER_SET_TYPES.forEach { type ->
            ordered.add(parameterSets.firstOrNull { it.type == type } ?: return null)
        }
        val buffer = ByteBuffer.allocate(ordered.sumOf { START_CODE.size + it.data.size })
        ordered.forEach { unit ->
            buffer.put(START_CODE)
            buffer.put(unit.data)
        }
        buffer.rewind()
        return buffer
    }

private class NalUnit(val type: Int, val data: ByteArray) {
        fun isParameterSet(): Boolean = type in PARAMETER_SET_TYPES
    }

    private fun splitNalUnits(stream: ByteArray): List<NalUnit> {
        val units = mutableListOf<NalUnit>()
        var index = 0
        var payloadStart = -1
        while (index + 2 < stream.size) {
            if (stream[index].toInt() != 0 || stream[index + 1].toInt() != 0) {
                index++
                continue
            }
            val codeLength = when {
                stream[index + 2].toInt() == 1 -> 3
                stream[index + 2].toInt() == 0 &&
                    index + 3 < stream.size &&
                    stream[index + 3].toInt() == 1 -> 4

                else -> {
                    index++
                    continue
                }
            }
            if (payloadStart >= 0) units.add(toNalUnit(stream, payloadStart, index))
            index += codeLength
            payloadStart = index
        }
        if (payloadStart in 0 until stream.size) units.add(toNalUnit(stream, payloadStart, stream.size))
        return units
    }

    private fun toNalUnit(stream: ByteArray, from: Int, to: Int): NalUnit {
        val data = stream.copyOfRange(from, to)
        val type = if (data.size >= NAL_HEADER_BYTES) {
            (data[0].toInt() ushr 1) and 0x3F
        } else {
            -1
        }
        return NalUnit(type, data)
    }

    private fun annexBAccessUnit(units: List<NalUnit>): ByteBuffer {
        val buffer = ByteBuffer.allocate(units.sumOf { START_CODE.size + it.data.size })
        units.forEach { unit ->
            buffer.put(START_CODE)
            buffer.put(unit.data)
        }
        buffer.rewind()
        return buffer
    }
}