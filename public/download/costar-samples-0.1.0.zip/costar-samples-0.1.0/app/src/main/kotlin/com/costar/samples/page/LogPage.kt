package com.costar.samples.page

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.method.ScrollingMovementMethod
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.costar.samples.core.DemoLog
import com.costar.samples.core.DemoSession
import com.costar.samples.ui.Palette
import com.costar.samples.ui.card
import com.costar.samples.ui.dp
import com.costar.samples.ui.monoBlock
import com.costar.samples.ui.pageHeader
import com.costar.samples.ui.rounded
import com.costar.samples.ui.screen
import com.costar.samples.ui.secondaryButton

internal class LogPage : Activity() {

    private val handler = Handler(Looper.getMainLooper())

    private lateinit var logView: TextView

    private lateinit var scroll: ScrollView

    private val listener: (List<String>) -> Unit = { lines -> handler.post { render(lines) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DemoSession.attach(this)
        setContentView(buildScreen())
        DemoLog.observe(listener)
        render(DemoLog.snapshot())
    }

    override fun onDestroy() {
        DemoLog.unobserve(listener)
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun buildScreen() = screen {
        addView(pageHeader("运行日志", "记录扫描、连接与各验证项的调用过程", onBack = { finish() }))

        logView = monoBlock("").apply {
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = rounded(Palette.NEUTRAL_BG, 8)
            movementMethod = ScrollingMovementMethod()
        }
        scroll = ScrollView(this@LogPage).apply {
            addView(logView)
        }

        val body = LinearLayout(this@LogPage).apply {
            orientation = LinearLayout.VERTICAL
            addView(
                scroll,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    dp(LOG_HEIGHT_DP)
                )
            )
        }

        addView(
            card(
                "日志",
                body,
                headerAction = secondaryButton("清空") { DemoLog.clear() }
            )
        )
    }

    private fun render(lines: List<String>) {
        logView.text = if (lines.isEmpty()) "暂无日志" else lines.joinToString("\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private companion object {
        const val LOG_HEIGHT_DP = 420
    }
}
