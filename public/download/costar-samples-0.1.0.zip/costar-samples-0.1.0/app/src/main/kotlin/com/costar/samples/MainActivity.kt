package com.costar.samples

import android.app.Activity
import android.os.Bundle
import android.widget.TextView
import com.costar.adapter.mock.MockAdapterCreator
import com.costar.api.CostarAPI
import com.costar.api.core.CostarCallback
import com.costar.api.core.CostarConfig
import com.costar.api.core.CostarError
import com.costar.api.core.CostarLogLevel
import com.costar.api.core.CostarResult
import com.costar.api.device.ConnectionType
import com.costar.api.device.DeviceDescriptor
import com.costar.api.device.VendorId
import com.costar.api.feature.Feature
import com.costar.api.platform.android.AndroidCostarPlatform
import com.costar.api.voice.AsrConfig
import com.costar.api.voice.AsrResult

class MainActivity : Activity() {

    private val output = StringBuilder()

    private lateinit var outputView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        outputView = TextView(this).apply { textSize = 14f }
        setContentView(outputView)

        CostarAPI.registerAdapter(MockAdapterCreator())
        CostarAPI.init(
            CostarConfig(appId = "costar-samples", logLevel = CostarLogLevel.DEBUG),
            AndroidCostarPlatform()
        )
        append("统一入口状态: ${CostarAPI.state()}")

        val deviceManager = CostarAPI.deviceManager()
        deviceManager.registerDevice(
            MOCK_DEVICE_ID,
            DeviceDescriptor(VendorId.VENDOR_A, "MOCK-1", "0.0.1", ConnectionType.WIFI)
        )

        when (val connected = deviceManager.connect(MOCK_DEVICE_ID)) {
            is CostarResult.Success -> append("设备已连接")
            is CostarResult.Failure -> append("设备连接失败: ${connected.error.message}")
        }

        append("语音识别能力支持: ${CostarAPI.features().isSupported(Feature.VOICE_ASR)}")
        append("眼动追踪支持程度: ${CostarAPI.features().level(Feature.INTERACTION_EYE_TRACKING)}")

        CostarAPI.voice().asr().start(AsrConfig(), object : CostarCallback<AsrResult> {
            override fun onSuccess(data: AsrResult) {
                append("识别结果: ${data.text} (置信度 ${data.confidence})")
            }

            override fun onError(error: CostarError) {
                append("识别失败: ${error.code} ${error.message}")
            }
        })
    }

    override fun onDestroy() {
        CostarAPI.release()
        super.onDestroy()
    }

    @Synchronized
    private fun append(line: String) {
        output.append(line).append('\n')
        runOnUiThread { outputView.text = output.toString() }
    }

    private companion object {
        const val MOCK_DEVICE_ID = "mock-1"
    }
}
