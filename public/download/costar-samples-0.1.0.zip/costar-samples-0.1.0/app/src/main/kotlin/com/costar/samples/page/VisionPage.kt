package com.costar.samples.page

import com.costar.samples.core.Domain

internal class VisionPage : VerificationPage() {
    override val domain: Domain = Domain.VISION
}
