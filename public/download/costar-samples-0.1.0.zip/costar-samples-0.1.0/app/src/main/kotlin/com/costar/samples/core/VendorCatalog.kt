package com.costar.samples.core

import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import com.costar.adapter.mock.MockAdapterCreator
import com.costar.api.device.VendorId
import com.costar.spi.AdapterCreator

internal object VendorCatalog {

    internal class Entry(
        val vendorId: VendorId,
        val displayName: String,
        val namePrefixes: List<String>,
        val modelOverride: String? = null,
        val creatorMetaKey: String = "",
        val creatorArgs: ((Context, String) -> Array<Any>)? = null,
        val create: ((Context, String) -> AdapterCreator)? = null
    ) {

        fun creator(context: Context, address: String): AdapterCreator? {
            create?.let { return it(context, address) }
            val className = metaValue(context, creatorMetaKey) ?: return null
            val args = creatorArgs?.invoke(context, address) ?: arrayOf(context, address)
            return reflect(className, args)
        }
    }

    private const val AUTH_FILE = "auth.lc"

    private const val SECRET_FILE = "client_secret.txt"

    /** 硬件适配模块自描述的创建器类名,随模块清单合并进本应用。 */
    private const val META_VENDOR_B_CREATOR = "costar.adapter.vendor-b.creator"

    private const val META_VENDOR_C_CREATOR = "costar.adapter.vendor-c.creator"

    private val allEntries: List<Entry> = listOf(
        Entry(
            vendorId = VendorId.VENDOR_B,
            displayName = "VENDOR_B",
            namePrefixes = listOf("Glasses", "CXR", "RV-", "RG-"),
            creatorMetaKey = META_VENDOR_B_CREATOR,
            creatorArgs = { context, mac ->
                arrayOf(
                    context,
                    mac,
                    readAsset(context, AUTH_FILE),
                    String(readAsset(context, SECRET_FILE)).trim()
                )
            }
        ),
        Entry(
            vendorId = VendorId.VENDOR_C,
            displayName = "VENDOR_C",
            namePrefixes = listOf("Xy_", "XyBle_"),
            creatorMetaKey = META_VENDOR_C_CREATOR
        ),
        Entry(
            vendorId = VendorId.VENDOR_A,
            displayName = "MOCK",
            namePrefixes = emptyList(),
            modelOverride = "MOCK-1",
            create = { _, _ -> MockAdapterCreator() }
        )
    )

    /** 仅保留创建器可用的条目:未参与打包的适配模块不会声明其类名。 */
    fun entries(context: Context): List<Entry> = allEntries.filter {
        it.create != null || metaValue(context, it.creatorMetaKey) != null
    }

    fun resolve(context: Context, deviceName: String): Entry? = entries(context).firstOrNull { entry ->
        entry.namePrefixes.any { deviceName.startsWith(it, ignoreCase = true) }
    }

    private fun metaValue(context: Context, key: String): String? {
        if (key.isBlank()) {
            return null
        }
        return runCatching {
            context.packageManager
                .getApplicationInfo(context.packageName, PackageManager.GET_META_DATA)
                .metaData?.getString(key)
        }.getOrNull()?.takeIf { it.isNotBlank() }
    }

    private fun reflect(className: String, args: Array<Any>): AdapterCreator? = runCatching {
        Class.forName(className)
            .getConstructor(*args.map(::argType).toTypedArray())
            .newInstance(*args) as AdapterCreator
    }.onFailure {
        Log.w(TAG, "适配模块不可用: $className, ${it.message}")
    }.getOrNull()

    private fun argType(value: Any): Class<*> = when (value) {
        is ByteArray -> ByteArray::class.java
        is Context -> Context::class.java
        else -> value.javaClass
    }

    private fun readAsset(context: Context, name: String): ByteArray = try {
        context.assets.open(name).use { it.readBytes() }
    } catch (t: Throwable) {
        Log.w(TAG, "读取鉴权文件失败: $name, ${t.message}")
        ByteArray(0)
    }

    private const val TAG = "CostarDemo"
}
