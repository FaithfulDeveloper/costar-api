package com.costar.samples.page

import com.costar.samples.core.Domain

internal class VoicePage : VerificationPage() {
    override val domain: Domain = Domain.VOICE
}
