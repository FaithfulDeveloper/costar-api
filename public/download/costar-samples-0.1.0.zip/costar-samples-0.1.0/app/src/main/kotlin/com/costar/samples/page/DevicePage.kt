package com.costar.samples.page

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.costar.api.core.CostarResult
import com.costar.samples.core.DemoLog
import com.costar.samples.core.DemoSession
import com.costar.samples.core.VendorCatalog
import com.costar.samples.ui.Palette
import com.costar.samples.ui.Tone
import com.costar.samples.ui.card
import com.costar.samples.ui.chip
import com.costar.samples.ui.dangerButton
import com.costar.samples.ui.dp
import com.costar.samples.ui.hint
import com.costar.samples.ui.pageHeader
import com.costar.samples.ui.primaryButton
import com.costar.samples.ui.rounded
import com.costar.samples.ui.screen
import com.costar.samples.ui.secondaryButton
import kotlin.concurrent.thread

@SuppressLint("MissingPermission")
internal class DevicePage : Activity() {

    private val connectedDevices = mutableListOf<DeviceRow>()

    private val bondedDevices = mutableListOf<DeviceRow>()

    private val scannedDevices = mutableListOf<DeviceRow>()

    private var selectedAddress: String? = null

    private var linkedAddress: String? = null

    private lateinit var linkChip: TextView
    private lateinit var linkDetail: TextView
    private lateinit var deviceContainer: LinearLayout
    private lateinit var deviceSummary: TextView
    private lateinit var scanButton: Button
    private lateinit var connectButton: Button
    private lateinit var disconnectButton: Button
    private lateinit var unbindButton: Button

    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var scanning = false

    @Volatile
    private var everScanned = false

    @Volatile
    private var connecting = false

    @Volatile
    private var disconnecting = false

    @Volatile
    private var unbinding = false

    @Volatile
    private var connectToken = 0

    private var scanWatchdog: Runnable? = null

    private var connectWatchdog: Runnable? = null

    private var linkWatchdog: Runnable? = null

    private val bluetooth: BluetoothAdapter?
        get() = (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    private val scanCallback = object : ScanCallback() {

        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val name = runCatching { device.name }.getOrNull() ?: return
            runOnUiThread {
                if (connectedDevices.any { it.address == device.address }) {
                    return@runOnUiThread
                }
                if (scannedDevices.none { it.address == device.address }) {
                    scannedDevices.add(
                        DeviceRow(
                            name = name,
                            address = device.address,
                            vendor = DemoSession.resolveVendor(name)?.displayName
                        )
                    )
                    DemoLog.append("扫描发现 $name (${device.address})")
                    renderDevices()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DemoSession.attach(this)
        setContentView(buildScreen())

        val missing = requiredPermissions().filter {
            checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            refreshDeviceLists()
        } else {
            requestPermissions(missing.toTypedArray(), REQUEST_PERMISSIONS)
        }
        renderAll()
    }

    override fun onStart() {
        super.onStart()
        refreshDeviceLists()
        startLinkWatch()
        renderAll()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        requestNames: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, requestNames, grantResults)
        if (requestCode == REQUEST_PERMISSIONS) {
            if (!hasBluetoothPermissions()) {
                DemoLog.append("缺少蓝牙权限,无法读取设备列表")
            } else {
                refreshDeviceLists()
            }
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) !=
                PackageManager.PERMISSION_GRANTED
            ) {
                DemoLog.append("缺少录音权限,录音采集将不可用")
            }
        }
    }

    override fun onStop() {
        stopScan(null)
        stopLinkWatch()
        super.onStop()
    }

    override fun onDestroy() {
        stopLinkWatch()
        mainHandler.removeCallbacksAndMessages(null)
        scanWatchdog = null
        connectWatchdog = null
        stopScan(null)
        super.onDestroy()
    }

private fun buildScreen(): View = screen {
        addView(pageHeader(title = "设备", subtitle = null, onBack = { finish() }))

        linkChip = chip("未连接", Tone.MUTED)
        linkDetail = TextView(this@DevicePage).apply {
            textSize = 13f
            setTextColor(Palette.MUTED)
            setPadding(dp(10), 0, 0, 0)
            layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        }
        disconnectButton = secondaryButton("断开连接") { onDisconnectClicked() }

        addView(
            card(
                "当前连接",
                LinearLayout(this@DevicePage).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(
                        LinearLayout(this@DevicePage).apply {
                            orientation = LinearLayout.HORIZONTAL
                            gravity = Gravity.CENTER_VERTICAL
                            addView(linkChip)
                            addView(linkDetail)
                        }
                    )
                    addView(
                        disconnectButton,
                        LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                            topMargin = dp(12)
                        }
                    )
                }
            )
        )

        deviceContainer = LinearLayout(this@DevicePage).apply { orientation = LinearLayout.VERTICAL }
        deviceSummary = hint("")
        scanButton = secondaryButton("开始扫描") { onScanClicked() }
        addView(
            card(
                title = "附近设备",
                body = LinearLayout(this@DevicePage).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(deviceContainer)
                    addView(deviceSummary)
                },
                subtitle = " ",
                headerAction = scanButton
            )
        )

        connectButton = primaryButton("连接") { onConnectClicked() }
        addView(
            connectButton,
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(12) }
        )

        unbindButton = dangerButton("解除系统配对") { onUnbindClicked() }
        addView(
            unbindButton,
            LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(8) }
        )
    }

    private fun renderAll() {
        renderStatus()
        renderDevices()
        renderButtons()
    }

    private fun renderStatus() {
        val alive = DemoSession.linkAlive()
        linkChip.text = if (alive) "已连接" else "未连接"
        applyTone(linkChip, if (alive) Tone.OK else Tone.MUTED)

        val descriptor = DemoSession.currentDevice()
        val vendor = DemoSession.currentVendorName()
        linkDetail.text = if (descriptor == null) {
            "尚未连接眼镜"
        } else {
            val vendorText = vendor?.let { " · $it" }.orEmpty()
            "${descriptor.model}$vendorText (${descriptor.vendorId.name})"
        }
        linkDetail.setTextColor(if (descriptor == null) Palette.MUTED else Palette.TEXT)
    }

    private fun renderDevices() {
        deviceContainer.removeAllViews()
        val rows = buildList {
            addAll(connectedDevices.map { it to RowState.CONNECTED })
            addAll(bondedDevices.map { it to RowState.BONDED })
            addAll(scannedDevices.map { it to RowState.SCANNED })
        }

        deviceSummary.text = when {
            !hasBluetoothPermissions() -> "缺少蓝牙权限,无法读取设备"
            rows.isEmpty() -> "暂无 BLE 设备。已连接的眼镜会自动出现在这里,其他眼镜需先配对再扫描。"
            else -> "共 ${rows.size} 台设备,点击行选中后连接"
        }

        rows.forEach { (row, state) -> deviceContainer.addView(deviceRowView(row, state)) }
    }

    private fun deviceRowView(row: DeviceRow, state: RowState): View {
        val selected = row.address == selectedAddress
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = rounded(
                if (selected) Palette.BRAND_BG else Palette.CARD,
                10,
                if (selected) Palette.BRAND else Palette.STROKE
            )
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply {
                topMargin = dp(8)
            }
            setOnClickListener {
                selectedAddress = row.address
                renderDevices()
                renderButtons()
            }

            addView(
                LinearLayout(this@DevicePage).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    addView(
                        TextView(this@DevicePage).apply {
                            text = row.name
                            textSize = 14f
                            setTextColor(Palette.TEXT)
                            typeface = Typeface.DEFAULT_BOLD
                            layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
                        }
                    )
                    val stateText = when (state) {
                        RowState.CONNECTED -> "已连接"
                        RowState.BONDED -> "已配对"
                        RowState.SCANNED -> "扫描发现"
                    }
                    addView(chip(stateText, if (state == RowState.CONNECTED) Tone.OK else Tone.MUTED))
                    addView(TextView(this@DevicePage).apply { text = " "; textSize = 6f })
                    addView(
                        chip(
                            row.vendor ?: "未识别",
                            if (row.vendor != null) Tone.BRAND else Tone.WARN
                        )
                    )
                }
            )
            addView(
                TextView(this@DevicePage).apply {
                    text = row.address
                    textSize = 12f
                    setTextColor(Palette.MUTED)
                    setPadding(0, dp(4), 0, 0)
                }
            )
        }
    }

    private fun renderButtons() {
        val busy = connecting || disconnecting || unbinding
        scanButton.text = when {
            scanning -> "停止扫描"
            everScanned -> "重新扫描"
            else -> "开始扫描"
        }
        scanButton.isEnabled = !busy
        connectButton.isEnabled = !busy && selectedAddress != null && !DemoSession.linkAlive()
        disconnectButton.isEnabled = !busy && DemoSession.runtimeReady()
        unbindButton.isEnabled = !busy && selectedAddress != null
    }

private fun onScanClicked() {
        if (scanning) {
            stopScan("手动停止扫描")
        } else {
            startScan()
        }
    }

    private fun startScan() {
        if (!hasBluetoothPermissions()) {
            requestPermissions(requiredPermissions(), REQUEST_PERMISSIONS)
            return
        }
        val scanner = bluetooth?.bluetoothLeScanner
        if (scanner == null) {
            toast("蓝牙不可用,请确认蓝牙已开启")
            return
        }
        val started = runCatching { scanner.startScan(scanCallback) }
        if (started.isFailure) {
            DemoLog.append("开启扫描失败: ${started.exceptionOrNull()?.message}")
            return
        }
        scanning = true
        everScanned = true
        DemoLog.append("开始扫描")
        renderButtons()

        scanWatchdog?.let { mainHandler.removeCallbacks(it) }
        val watchdog = Runnable { stopScan("扫描已超时,自动停止") }
        scanWatchdog = watchdog
        mainHandler.postDelayed(watchdog, SCAN_TIMEOUT_MS)
    }

    private fun stopScan(reason: String?) {
        scanWatchdog?.let { mainHandler.removeCallbacks(it) }
        scanWatchdog = null
        if (!scanning) return
        scanning = false
        runCatching { bluetooth?.bluetoothLeScanner?.stopScan(scanCallback) }
        reason?.let { DemoLog.append(it) }
        renderButtons()
    }

private fun onConnectClicked() {
        val address = selectedAddress ?: return
        val row = currentRows().firstOrNull { it.address == address } ?: return
        val entry = DemoSession.resolveVendor(row.name)
        if (entry == null) {
            showVendorPicker(row)
        } else {
            connect(row, entry)
        }
    }

    private fun showVendorPicker(row: DeviceRow) {
        val entries = DemoSession.vendorEntries()
        // 消息与选项列表共用同一内容位,同时设置会让列表不显示,故把说明并入标题。
        AlertDialog.Builder(this)
            .setTitle("${row.name} 未匹配到已知厂商,请选择适配模块")
            .setItems(entries.map { it.displayName }.toTypedArray()) { _, index ->
                connect(row, entries[index])
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun connect(row: DeviceRow, entry: VendorCatalog.Entry) {
        stopScan(null)
        connecting = true
        connectToken++
        val token = connectToken
        DemoLog.append("选中设备 ${row.name} (${row.address}),厂商 ${entry.displayName}")
        renderButtons()

        connectWatchdog?.let { mainHandler.removeCallbacks(it) }
        val watchdog = Runnable {
            if (connecting && token == connectToken) {
                connecting = false
                DemoLog.append("连接超时,释放资源")
                thread { DemoSession.release("连接超时") }
                renderAll()
            }
        }
        connectWatchdog = watchdog
        mainHandler.postDelayed(watchdog, CONNECT_TIMEOUT_MS)

        thread {
            val result = DemoSession.connect(row.name, row.address, entry)
            mainHandler.post {
                if (token != connectToken) {
                    DemoLog.append("忽略已过期的连接结果")
                    return@post
                }
                connectWatchdog?.let { mainHandler.removeCallbacks(it) }
                connectWatchdog = null
                connecting = false
                when (result) {
                    is CostarResult.Success -> {
                        linkedAddress = row.address
                        selectedAddress = row.address
                        DemoLog.append("连接成功,链路状态: ${DemoSession.linkAlive()}")
                    }
                    is CostarResult.Failure -> {
                        DemoLog.append("连接失败: ${result.error.code.name} ${result.error.message}")
                        thread { DemoSession.release("连接失败") }
                    }
                }
                refreshDeviceListsNow()
                renderAll()
            }
        }
    }

    private fun onDisconnectClicked() {
        disconnecting = true
        connectToken++
        renderButtons()
        thread {
            DemoSession.release("用户断开")
            mainHandler.post {
                disconnecting = false
                linkedAddress = null
                selectedAddress = null
                refreshDeviceListsNow()
                renderAll()
            }
        }
    }

    private fun onUnbindClicked() {
        val address = selectedAddress ?: return
        val adapter = bluetooth ?: return
        val device = runCatching { adapter.getRemoteDevice(address) }.getOrNull()
        if (device == null) {
            toast("无法获取该设备")
            return
        }
        unbinding = true
        renderButtons()
        thread {
            val ok = runCatching {
                device.javaClass.getMethod("removeBond").invoke(device) as? Boolean
            }.getOrNull() == true
            mainHandler.post {
                unbinding = false
                DemoLog.append(if (ok) "已解除系统配对: $address" else "解除系统配对失败: $address")
                refreshDeviceListsNow()
                renderButtons()
            }
        }
    }

private fun refreshDeviceLists() {
        runOnUiThread { refreshDeviceListsNow() }
    }

    private fun refreshDeviceListsNow() {
        if (!hasBluetoothPermissions()) return
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager ?: return
        val adapter = manager.adapter ?: return

        val connectedAddresses = runCatching {
            runCatching { manager.getConnectedDevices(BluetoothProfile.GATT) }
                .getOrDefault(emptyList())
                .map { it.address }
        }.getOrDefault(emptyList())

        val bonded = runCatching { adapter.bondedDevices.toList() }
            .getOrDefault(emptyList())
            .filter { it.isBle() }

        val connected = mutableListOf<DeviceRow>()
        bonded.forEach { device ->
            if (device.address in connectedAddresses || device.address == linkedAddress) {
                connected.add(device.toRow())
            }
        }
        connectedDevices.clear()
        connectedDevices.addAll(connected)

        bondedDevices.clear()
        bonded.forEach { device ->
            if (connectedDevices.none { it.address == device.address }) {
                bondedDevices.add(device.toRow())
            }
        }

        scannedDevices.removeAll { scanned ->
            connectedDevices.any { it.address == scanned.address } ||
                bondedDevices.any { it.address == scanned.address }
        }

        renderDevices()
    }

    private fun android.bluetooth.BluetoothDevice.isBle(): Boolean =
        type == android.bluetooth.BluetoothDevice.DEVICE_TYPE_LE ||
            type == android.bluetooth.BluetoothDevice.DEVICE_TYPE_DUAL

    private fun android.bluetooth.BluetoothDevice.toRow(): DeviceRow {
        val label = runCatching { name }.getOrNull() ?: address
        return DeviceRow(label, address, DemoSession.resolveVendor(label)?.displayName)
    }

    private fun currentRows(): List<DeviceRow> = connectedDevices + bondedDevices + scannedDevices

private fun startLinkWatch() {
        stopLinkWatch()
        val watchdog = object : Runnable {
            override fun run() {
                renderStatus()
                renderButtons()
                mainHandler.postDelayed(this, LINK_POLL_INTERVAL_MS)
            }
        }
        linkWatchdog = watchdog
        mainHandler.postDelayed(watchdog, LINK_POLL_INTERVAL_MS)
    }

    private fun stopLinkWatch() {
        linkWatchdog?.let { mainHandler.removeCallbacks(it) }
        linkWatchdog = null
    }

private fun applyTone(view: TextView, tone: Tone) {
        view.setTextColor(tone.fg)
        view.background = rounded(tone.bg, 6)
    }

    private fun bluetoothPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }

    private fun requiredPermissions(): Array<String> =
        bluetoothPermissions() + Manifest.permission.RECORD_AUDIO

    private fun hasBluetoothPermissions(): Boolean = bluetoothPermissions().all {
        checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED
    }

    private fun toast(text: String) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
    }

    private class DeviceRow(val name: String, val address: String, val vendor: String?)

    private enum class RowState { CONNECTED, BONDED, SCANNED }

    private companion object {
        const val REQUEST_PERMISSIONS = 1001

        const val SCAN_TIMEOUT_MS = 15_000L

        const val CONNECT_TIMEOUT_MS = 20_000L

        const val LINK_POLL_INTERVAL_MS = 2_000L

        const val WRAP_CONTENT = LinearLayout.LayoutParams.WRAP_CONTENT

        const val MATCH_PARENT = LinearLayout.LayoutParams.MATCH_PARENT
    }
}
