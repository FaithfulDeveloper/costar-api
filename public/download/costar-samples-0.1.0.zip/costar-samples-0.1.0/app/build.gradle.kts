// 示例应用:演示统一入口的初始化与各能力域调用。
//
// 本模块以 AAR 方式接入,依赖产物目录中的已发布 AAR。
//   产物目录缺省为 libs/,可用 -Pcostar.aarDir 指定;此时适配模块按 -Pcostar.adapters 选择,
//   未引入的硬件适配模块不参与打包,其登记条目在运行期自动不可用。
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

/** 读取构建期注入值;未声明时返回空串,对应登记条目在运行期自动不可用。 */
fun injected(key: String): String = providers.gradleProperty(key).getOrElse("")

/** 为 true 时以 AAR 方式接入,用于在脱离本工程的情况下单独构建本示例。 */
val useAar = injected("costar.useAar").toBoolean()

/** 以 AAR 方式接入时的产物版本号,与产物文件名中的版本一致。 */
val sdkVersion = injected("costar.sdkVersion")

/** 以 AAR 方式接入时产物所在目录(相对本模块),缺省为 libs。 */
val aarDir = injected("costar.aarDir").takeIf { it.isNotBlank() } ?: "libs"

/** 参与构建的适配模块,缺省为全部;取值 mock / vendorB / vendorC。 */
val adapters = injected("costar.adapters")
    .takeIf { it.isNotBlank() }
    ?.split(",")
    ?.map { it.trim() }
    ?.filter { it.isNotEmpty() }
    ?: listOf("mock", "vendorB", "vendorC")

android {
    namespace = "com.costar.samples"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.costar.samples"
        // 随适配模块中要求最高者取齐。
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    if (useAar) {
        implementation(files("$aarDir/costar-api-$sdkVersion.aar"))
        if ("mock" in adapters) {
            implementation(files("$aarDir/costar-adapter-mock-$sdkVersion.aar"))
        }
        if ("vendorB" in adapters) {
            implementation(files("$aarDir/costar-adapter-vendor-b-$sdkVersion.aar"))
        }
        if ("vendorC" in adapters) {
            implementation(files("$aarDir/costar-adapter-vendor-c-$sdkVersion.aar"))
        }
    }
}
